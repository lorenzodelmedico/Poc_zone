import importlib.util
import io
import json
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app.settings import ROOT

spec = importlib.util.spec_from_file_location("install_echarts", ROOT / "scripts/install_echarts.py")
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


def archive(version="5.6.0"):
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as tar:
        for name, content in {
            "package/package.json": json.dumps({"name": "echarts", "version": version}).encode(),
            "package/dist/echarts.min.js": b"/* fake fixture: not ECharts */",
            "package/LICENSE": b"fake license fixture", "package/NOTICE": b"fake notice fixture",
            "../../not-extracted.txt": b"unsafe name fixture",
        }.items():
            info = tarfile.TarInfo(name)
            info.size = len(content)
            tar.addfile(info, io.BytesIO(content))
    return output.getvalue()


class InstallerTests(unittest.TestCase):
    def test_only_expected_files_are_written(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "vendor"
            with patch.object(installer, "DEST", destination):
                installer.install(archive())
            self.assertEqual({p.name for p in destination.iterdir()}, {"echarts.min.js", "ECHARTS_LICENSE", "ECHARTS_NOTICE"})

    def test_wrong_version_is_rejected(self):
        with self.assertRaises(ValueError):
            installer.install(archive("0.0.0"))
