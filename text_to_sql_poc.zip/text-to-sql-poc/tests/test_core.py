import json
import tempfile
import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal
from pathlib import Path

from app.auth import TokenProvider
from app.errors import AppError
from app.formatter import format_result
from app.http_client import post_json
from app.llm import generate_sql, parse_generation
from app.metadata import load_metadata
from app.settings import ROOT, Settings


class TokenTests(unittest.TestCase):
    def settings(self, **kwargs):
        return replace(Settings(metadata_path=ROOT / "config/metadata.example.json",
                                auth_url="https://example.invalid/token", auth_id="fake-id",
                                auth_password="fake-password"), **kwargs)

    def test_token_nested_response_and_form_payload(self):
        calls = []
        def transport(url, payload, **kwargs):
            calls.append((payload, kwargs))
            return {"data": {"token": "fake-token", "ttl": 100}}
        settings = self.settings(auth_token_field="data.token", auth_expires_field="data.ttl",
                                 auth_body_format="form", auth_id_field="username")
        provider = TokenProvider(settings, transport=transport, clock=lambda: 0)
        self.assertEqual(provider.get_token(), "fake-token")
        self.assertEqual(provider.get_token(), "fake-token")
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][0], {"username": "fake-id", "password": "fake-password"})
        self.assertEqual(calls[0][1]["body_format"], "form")

    def test_expiry_and_invalidation(self):
        now = [0]
        calls = []
        def transport(*args, **kwargs):
            calls.append(1)
            return {"access_token": "fake", "expires_in": 100}
        provider = TokenProvider(self.settings(), transport, lambda: now[0])
        provider.get_token()
        now[0] = 91
        provider.get_token()
        provider.invalidate()
        provider.get_token()
        self.assertEqual(len(calls), 3)

    def test_unknown_expiry_is_not_cached(self):
        calls = []
        def transport(*args, **kwargs):
            calls.append(1)
            return {"access_token": "fake"}
        provider = TokenProvider(self.settings(), transport)
        provider.get_token()
        provider.get_token()
        self.assertEqual(len(calls), 2)

    def test_missing_token_is_controlled(self):
        provider = TokenProvider(self.settings(), lambda *a, **kw: {"message": "fake-error"})
        with self.assertRaises(AppError) as error:
            provider.get_token()
        self.assertEqual(error.exception.code, "AUTH_TOKEN_MISSING")

    def test_invalid_extra_payload_is_rejected(self):
        provider = TokenProvider(self.settings(auth_extra_json="[]"))
        with self.assertRaises(AppError):
            provider.get_token()

    def test_nonfinite_expiry_not_cached(self):
        calls = []
        def transport(*args, **kwargs):
            calls.append(1)
            return {"access_token": "fake", "expires_in": "Infinity"}
        provider = TokenProvider(self.settings(), transport)
        provider.get_token()
        provider.get_token()
        self.assertEqual(len(calls), 2)


class GenerationTests(unittest.TestCase):
    def test_json_and_code_fence(self):
        response = {"status": "ok", "sql": "SELECT fake", "assumptions": []}
        self.assertEqual(parse_generation("```json\n" + json.dumps(response) + "\n```"), response)

    def test_invalid_response(self):
        for value in ["not json", "[]", '{"status":"ok","sql":null}',
                      '{"status":"clarification_needed","sql":"SELECT x","clarification_question":"Quelle date ?"}']:
            with self.subTest(value=value), self.assertRaises(AppError):
                parse_generation(value)

    def test_clarification(self):
        data = {"status": "clarification_needed", "sql": None, "clarification_question": "Quelle année ?"}
        self.assertEqual(parse_generation(json.dumps(data))["status"], "clarification_needed")

    def test_actual_chat_contract(self):
        settings = Settings(metadata_path=Path("unused"), llm_chat_url="https://example.invalid/chat",
                            llm_model="internal-model-placeholder")
        calls = []
        def transport(url, payload, **kwargs):
            calls.append(payload)
            return {"choices": [{"message": {"content": '{"status":"ok","sql":"SELECT fake"}'}}]}
        result = generate_sql(settings, {"view": "fake"}, "question synthétique", transport)
        self.assertEqual(result["status"], "ok")
        self.assertEqual(calls[0]["messages"][-1]["role"], "user")
        self.assertFalse(calls[0]["stream"])


class FormatterTests(unittest.TestCase):
    def test_decimal_date_and_null(self):
        result = format_result([{"x": date(2025, 1, 1), "y": Decimal("2.5")}, {"x": None, "y": None}], "bar")
        self.assertEqual(result, [{"x": "2025-01-01", "y": 2.5}, {"x": "(sans catégorie)", "y": None}])

    def test_line_sorted_chronologically(self):
        result = format_result([{"x": date(2025, 2, 1), "y": 3}, {"x": date(2025, 1, 1), "y": 2}], "line")
        self.assertEqual(result[0]["x"], "2025-01-01")

    def test_text_category_not_a_temporal_line(self):
        with self.assertRaises(AppError):
            format_result([{"x": "Category A", "y": 2}], "line")

    def test_nonfinite_or_text_measure_rejected(self):
        for value in [float("nan"), float("inf"), "2.5", True, Decimal("NaN")]:
            with self.subTest(value=value), self.assertRaises(AppError):
                format_result([{"x": "A", "y": value}], "bar")


class MetadataTests(unittest.TestCase):
    def test_example(self):
        self.assertEqual(load_metadata(ROOT / "config/metadata.example.json")["view"]["name"], "v_metric_demo")

    def test_invalid_identifier(self):
        data = load_metadata(ROOT / "config/metadata.example.json")
        data["view"]["schema"] = 'public; SELECT something'
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "invalid.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            with self.assertRaises(AppError):
                load_metadata(path)

    def test_missing_file(self):
        with self.assertRaises(AppError):
            load_metadata(Path("does-not-exist.json"))


class HttpSettingsTests(unittest.TestCase):
    def test_non_http_url_rejected(self):
        with self.assertRaises(AppError):
            post_json("file:///fake", {})

    def test_placeholders_rejected(self):
        with self.assertRaises(AppError) as error:
            Settings(metadata_path=Path("unused")).check_live()
        self.assertEqual(error.exception.code, "CONFIG_INCOMPLETE")


if __name__ == "__main__":
    unittest.main()
