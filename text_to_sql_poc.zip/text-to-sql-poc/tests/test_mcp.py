import importlib.util
import os
import unittest
from unittest.mock import patch

from app.settings import ROOT


@unittest.skipUnless(importlib.util.find_spec("mcp"), "Dépendance mcp non installée")
class MCPTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_stdio_tools(self):
        from app.mcp_client import call_metadata_tool, metadata_session
        with patch.dict(os.environ, {"METADATA_PATH": str(ROOT / "config/metadata.example.json")}):
            async with metadata_session() as session:
                view = await call_metadata_tool(session, "get_view_metadata")
                charts = await call_metadata_tool(session, "get_chart_catalog")
        self.assertEqual(view["view"]["name"], "v_metric_demo")
        self.assertEqual([c["id"] for c in charts["charts"]], ["bar", "line"])


if __name__ == "__main__":
    unittest.main()
