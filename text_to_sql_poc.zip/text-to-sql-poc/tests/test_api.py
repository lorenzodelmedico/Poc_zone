import importlib.util
import os
import unittest
from unittest.mock import patch

from app.settings import ROOT

DEPENDENCIES = all(importlib.util.find_spec(name) for name in ["fastapi", "mcp", "sqlglot", "dotenv", "httpx"])


@unittest.skipUnless(DEPENDENCIES, "Dépendances API/MCP/SQL non installées")
class APITests(unittest.TestCase):
    def setUp(self):
        from fastapi.testclient import TestClient
        from app.api import app
        env = {
            "METADATA_PATH": str(ROOT / "config/metadata.example.json"),
            "LLM_CHAT_URL": "https://example.invalid/v1/chat/completions",
            "LLM_MODEL": "nemotron-3-super-120b-a12b-nvfp4", "AUTH_URL": "https://example.invalid/token",
            "AUTH_ID": "fake", "AUTH_PASSWORD": "fake", "PGHOST": "example.invalid",
            "PGDATABASE": "fake", "PGUSER": "fake", "PGSSLMODE": "verify-full",
        }
        patcher = patch.dict(os.environ, env)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.client = TestClient(app)
        self.client.__enter__()
        self.addCleanup(self.client.__exit__, None, None, None)

    def test_health_and_real_mcp_catalog(self):
        self.assertEqual(self.client.get("/health").status_code, 200)
        response = self.client.get("/api/catalog")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["view"]["name"], "v_metric_demo")

    def test_complete_pipeline_with_fake_llm_and_fake_database(self):
        generated = {"status": "ok", "sql": 'SELECT "category" AS x, SUM("measure") AS y FROM "public"."v_metric_demo" GROUP BY "category" ORDER BY x', "assumptions": []}
        with patch("app.api.generate_sql", return_value=generated), patch("app.api.execute_query", return_value=[{"x": "A", "y": 4}]) as db:
            response = self.client.post("/api/query", json={"question": "Total par catégorie", "chart_type": "bar"})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["rows"], [{"x": "A", "y": 4.0}])
        self.assertTrue(db.called)

    def test_invalid_sql_never_reaches_database(self):
        generated = {"status": "ok", "sql": "DELETE FROM public.v_metric_demo", "assumptions": []}
        with patch("app.api.generate_sql", return_value=generated), patch("app.api.execute_query") as db:
            response = self.client.post("/api/query", json={"question": "Requête interdite"})
        self.assertEqual(response.status_code, 422)
        db.assert_not_called()

    def test_clarification_never_reaches_database(self):
        generated = {"status": "clarification_needed", "sql": None, "assumptions": [], "clarification_question": "Quelle période ?"}
        with patch("app.api.generate_sql", return_value=generated), patch("app.api.execute_query") as db:
            response = self.client.post("/api/query", json={"question": "Total récent"})
        self.assertEqual(response.json()["status"], "clarification_needed")
        db.assert_not_called()


if __name__ == "__main__":
    unittest.main()
