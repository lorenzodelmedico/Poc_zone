import importlib.util
import unittest

from app.errors import AppError
from app.metadata import load_metadata
from app.settings import ROOT
from app.sql_validator import validate_sql

SQLGLOT_AVAILABLE = importlib.util.find_spec("sqlglot") is not None


@unittest.skipUnless(SQLGLOT_AVAILABLE, "Dépendance sqlglot non installée")
class SQLTests(unittest.TestCase):
    def setUp(self):
        self.metadata = load_metadata(ROOT / "config/metadata.example.json")

    def query(self, x='"category"', y='SUM("measure")', table='"public"."v_metric_demo"', suffix=""):
        return f"SELECT {x} AS x, {y} AS y FROM {table} {suffix} GROUP BY {x} ORDER BY x"

    def test_reference_aggregation_and_limit(self):
        sql = validate_sql(self.query(), self.metadata, 10)
        self.assertIn("LIMIT 11", sql)

    def test_monthly_date_trunc(self):
        validate_sql(self.query(x='DATE_TRUNC(\'month\', "event_date")'), self.metadata)

    def test_date_filter(self):
        validate_sql(self.query(suffix='WHERE "event_date" >= CAST(\'2025-01-01\' AS DATE)'), self.metadata)

    def test_existing_limit_preserved(self):
        sql = validate_sql(self.query() + " LIMIT 3", self.metadata, 10)
        self.assertIn("LIMIT 3", sql)

    def test_count_star_requires_explicit_permission(self):
        with self.assertRaises(AppError):
            validate_sql(self.query(y="COUNT(*)"), self.metadata)
        self.metadata["allow_count_rows"] = True
        validate_sql(self.query(y="COUNT(*)"), self.metadata)

    def test_unauthorized_table_and_column(self):
        for sql in [self.query(table='"public"."other"'), self.query(x='"secret"')]:
            with self.subTest(sql=sql), self.assertRaises(AppError):
                validate_sql(sql, self.metadata)

    def test_writes_and_multistatement(self):
        for sql in ["DELETE FROM public.v_metric_demo", self.query() + "; SELECT 1", self.query().replace("FROM", "INTO new_table FROM", 1)]:
            with self.subTest(sql=sql), self.assertRaises(AppError):
                validate_sql(sql, self.metadata)

    def test_unsafe_functions_and_subqueries(self):
        for sql in [self.query(y="pg_sleep(1)"), self.query(y="pg_catalog.count(*)"),
                    self.query(x="(SELECT secret FROM other)"),
                    self.query().replace('FROM "public"."v_metric_demo"', 'FROM "public"."v_metric_demo" CROSS JOIN other')]:
            with self.subTest(sql=sql), self.assertRaises(AppError):
                validate_sql(sql, self.metadata)

    def test_cte_union_and_window(self):
        queries = ["WITH a AS (SELECT 1) " + self.query(), self.query() + " UNION " + self.query(),
                   self.query(y='SUM("measure") OVER ()')]
        for sql in queries:
            with self.subTest(sql=sql), self.assertRaises(AppError):
                validate_sql(sql, self.metadata)

    def test_wrong_aggregation_and_shape(self):
        for sql in [self.query(y='SUM("category")'), self.query(y='"measure"'),
                    self.query().replace(" AS y", " AS other"), self.query(x='"measure"')]:
            with self.subTest(sql=sql), self.assertRaises(AppError):
                validate_sql(sql, self.metadata)


if __name__ == "__main__":
    unittest.main()
