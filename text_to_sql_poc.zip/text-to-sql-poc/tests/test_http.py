import io
import json
import unittest
from urllib.error import HTTPError
from unittest.mock import patch

from app.errors import AppError
from app.http_client import NoRedirect, post_json


class HttpTests(unittest.TestCase):
    def test_json_post_body_and_header(self):
        with patch("app.http_client.build_opener") as factory:
            factory.return_value.open.return_value = io.BytesIO(b'{"access_token":"fake"}')
            result = post_json("https://example.invalid/token", {"id": "fake-id"}, headers={"Authorization": "Bearer fake"})
            request = factory.return_value.open.call_args.args[0]
        self.assertEqual(result["access_token"], "fake")
        self.assertEqual(json.loads(request.data), {"id": "fake-id"})
        self.assertEqual(request.get_header("Authorization"), "Bearer fake")

    def test_form_post_body(self):
        with patch("app.http_client.build_opener") as factory:
            factory.return_value.open.return_value = io.BytesIO(b'{}')
            post_json("https://example.invalid/token", {"id": "fake id"}, body_format="form")
            request = factory.return_value.open.call_args.args[0]
        self.assertEqual(request.data, b"id=fake+id")

    def test_http_error_is_sanitized(self):
        with patch("app.http_client.build_opener") as factory:
            factory.return_value.open.side_effect = HTTPError("https://sensitive.invalid/token", 401, "private detail", {}, None)
            with self.assertRaises(AppError) as error:
                post_json("https://example.invalid/token", {})
        self.assertIn("401", error.exception.message)
        self.assertNotIn("sensitive", error.exception.message)
        self.assertNotIn("private", error.exception.message)

    def test_redirect_is_blocked(self):
        self.assertIsNone(NoRedirect().redirect_request(None, None, 302, "redirect", {}, "https://elsewhere.invalid"))
