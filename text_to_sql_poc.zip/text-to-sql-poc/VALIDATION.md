# État des vérifications de la livraison

Date : 3 novembre 2026.

## Contrôles exécutés

| Contrôle | Résultat | Limite |
|---|---|---|
| Tests du cache de jeton, de l'expiration, des réponses imbriquées et du contrat d'authentification | Réussite | Réponses de service simulées ; aucun identifiant réel. |
| Tests du contrat HTTP JSON/form et de la gestion des erreurs | Réussite | Transport HTTP simulé ; aucune preuve de connectivité externe. |
| Tests du JSON retourné par le modèle et des clarifications | Réussite | Sorties de modèle simulées ; aucune inférence réelle. |
| Tests du formatage JSON des dates, nombres, valeurs nulles et courbes temporelles | Réussite | Jeux de données synthétiques. |
| Tests de lecture des métadonnées et de rejet des identifiants invalides | Réussite | Fichier d'exemple fictif. |
| Tests de préparation des fichiers ECharts | Réussite | Archive de test artificielle ; aucun vrai fichier ECharts téléchargé. |
| Compilation syntaxique des modules Python | Réussite | Ne valide ni les dépendances ni les services. |
| Vérification syntaxique du JavaScript avec Node | Réussite | Aucun rendu navigateur ni chargement réel d'ECharts. |
| Contrôle des liens locaux Markdown et du contenu de l'archive | Effectué lors de la préparation du ZIP | N'inclut pas la disponibilité des liens externes. |

Commande de tests :

```bash
python -m unittest discover -s tests -v
```

**40 tests découverts : 25 exécutés avec succès, 15 non exécutés car leurs dépendances ne sont pas installées dans l'environnement de préparation.**

## Contrôles fournis mais non exécutés ici

- 10 tests SQLGlot : requêtes de référence, agrégations, dates, bornes, rejets des fonctions et constructions non autorisées.
- 1 test de communication réelle avec le MCP sur stdio.
- 4 tests API : catalogue MCP, pipeline avec LLM/BDD simulés, blocage du SQL et absence d'exécution en cas de clarification.

L'installation des dépendances a été tentée mais l'accès au registre de paquets n'est pas disponible dans cet environnement. Ces tests sont inclus ; ils devront être exécutés après installation des dépendances sur l'environnement cible. Ils ne sont pas présentés comme réussis.

## Vérifications nécessitant l'environnement cible

- Compatibilité effective du service interne avec le contrat `chat/completions`.
- Qualité des requêtes produites par le modèle interne sur les questions retenues.
- Contrat réel du service de jeton, durée de validité et gestion du renouvellement.
- Acceptation du jeton comme mot de passe PostgreSQL, ou adaptation de l'autre mécanisme.
- Réseau, certificats, droits du rôle et définition réelle de la vue.
- Exécution SQL et exactitude des résultats par rapport aux références métier.
- Installation du véritable ECharts et rendu de l'interface dans le navigateur.

Le code source du parcours est fourni, mais aucune validation complète sur des services réels n'est revendiquée. `DB_TOKEN_MODE=custom` est un point d'intégration explicite, pas un connecteur universel implémenté.
