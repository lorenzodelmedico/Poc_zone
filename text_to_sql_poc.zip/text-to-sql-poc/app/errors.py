class AppError(Exception):
    """Erreur publique contrôlée, sans réponse brute des services externes."""

    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status
