# POC Text-to-SQL avec MCP et ECharts

Application locale minimale : une question devient une requête PostgreSQL sur une seule vue autorisée. Le backend obtient le schéma via un véritable serveur MCP sur stdio, appelle un LLM interne, contrôle le SQL, récupère un jeton BDD, exécute la lecture et retourne un JSON. L'interface affiche un tableau et un graphique ECharts prédéfini.

**Démarrage : suivre [GUIDE_UTILISATION.md](GUIDE_UTILISATION.md) dans l'ordre.**

Après installation et configuration :

```bash
python scripts/check_config.py
python run.py
```

Interface : <http://127.0.0.1:8000>. Arrêt : `Ctrl+C`.

## Contenu

- [GUIDE_UTILISATION.md](GUIDE_UTILISATION.md) : installation Windows/Git Bash, correspondance des paramètres, métadonnées, authentification, lancement, essais et dépôt GitHub.
- [PROMPT_PROJET.md](PROMPT_PROJET.md) : cadrage autonome du projet pour un assistant de développement.
- [VALIDATION.md](VALIDATION.md) : contrôles réalisés et limites de vérification.
- [SOURCES.md](SOURCES.md) : cinq sources officielles et rôle dans la réalisation.
- `app/` : API, MCP, LLM, validation SQL, authentification, accès aux données et formatage.
- `frontend/` : page HTML/JavaScript/CSS, sans compilation frontend.
- `config/metadata.example.json` : schéma entièrement fictif à copier puis adapter.
- `.env.example` : paramètres à copier vers `.env`.
- `examples/` : vue SQL synthétique facultative et requêtes de référence.
- `tests/` : tests unitaires, contrôle SQL, MCP stdio et API avec LLM/BDD simulés.

Le ZIP contient toutes les sources applicatives. Les paquets Python et le fichier tiers ECharts s'installent séparément, depuis des sources autorisées. Aucun téléchargement de dépendance ne se produit au démarrage.

## Limites du premier périmètre

Une seule vue, un seul regroupement, une mesure agrégée, une requête par question. Les deux sorties SQL portent toujours les alias `x` et `y`. Barres pour les catégories ; courbe pour les dates. Aucune jointure, CTE, sous-requête ou génération de JavaScript par le modèle. Les résultats ne sont pas renvoyés au LLM.

Le connecteur fourni utilise le jeton comme mot de passe PostgreSQL **uniquement si ce mécanisme est accepté par la base ou sa passerelle**. Les autres mécanismes ont un point d'adaptation explicite dans `app/database.py` ; ils ne sont pas implémentés par défaut.

POC local mono-utilisateur lié à `127.0.0.1`. Pas d'authentification utilisateur, SSO, filtrage individuel ou déploiement public. Le compte de base est celui configuré pour ce POC. Les droits fins par personne devront être traités avant un usage partagé.

Un SQL accepté par le validateur peut encore exprimer une mauvaise interprétation métier. La validation par résultats de référence reste nécessaire. Les dépendances ne sont pas figées par un fichier de verrouillage validé : `requirements.txt` définit des bornes de compatibilité.
