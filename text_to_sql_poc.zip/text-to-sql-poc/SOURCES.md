# Sources techniques

Consultation : 3 novembre 2026. Sources primaires uniquement. Les pourcentages indiquent une répartition éditoriale estimée de leur contribution aux choix techniques documentés ; ce ne sont ni des probabilités de réussite ni des mesures scientifiques.

| Référence | Source officielle | Contribution estimée | Utilisation dans le projet |
|---|---|---:|---|
| S1 | [MCP — SDK Python officiel](https://github.com/modelcontextprotocol/python-sdk) | 25 % | Serveur FastMCP, transport stdio, session cliente et appels d'outils. |
| S2 | [PostgreSQL — paramètres de connexion](https://www.postgresql.org/docs/current/runtime-config-client.html) | 20 % | Transaction en lecture seule, search_path et limite de durée d'instruction. |
| S3 | [Psycopg 3 — transactions](https://www.psycopg.org/psycopg3/docs/basic/transactions.html) | 20 % | Gestion des connexions, transactions et exceptions de la base. |
| S4 | [SQLGlot — documentation API](https://sqlglot.com/sqlglot.html) | 20 % | Analyse du dialecte PostgreSQL et parcours d'arbre SQL avant exécution. |
| S5 | [Apache ECharts — dataset](https://echarts.apache.org/handbook/en/concepts/dataset/) | 15 % | Séparation des données JSON et des modèles fixes de graphiques. |

La liste positive des constructions SQL, les alias x/y, la configuration statique, les fichiers d'exemple et le plan séquentiel sont des choix d'implémentation du POC. Les sources ne prouvent pas la correction du projet ni la qualité d'un modèle sur une vue donnée.

Le contrat exact du service de jeton et les règles métier sont inconnus : les paramètres et points d'adaptation sont fournis sans inventer de mécanisme interne.
