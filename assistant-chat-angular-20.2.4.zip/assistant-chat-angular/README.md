# Assistant RH – Angular

Application autonome en Angular **20.2.4**. La configuration de démonstration simule le profil, l’historique, les tours, la vérification, les avis et l’indexation. La configuration de production envoie les requêtes à l’API Python à raccorder.

## Lancement de la démonstration

Node.js 20.19+, 22.12+ ou 24.x dans les plages du `package.json`. Les dépendances peuvent être résolues par le registre npm configuré sur le poste.

```powershell
npm install
npm start
```

L’application est servie sur [localhost:4200](http://localhost:4200). Les données de démonstration sont fictives et persistent lors d’une actualisation dans le même onglet.

| Parcours | Démonstration |
| --- | --- |
| Historique et profil | Deux conversations sont déjà présentes. La carte de profil s’ouvre dans l’en-tête. |
| Vérification et texte original | Dans « Demande de formation », soumettre une question sur la formation. « Démo refus » affiche un refus lorsque la recherche documentaire et la vérification sont actives. |
| Évaluer la réponse | Ouvrir le formulaire sous une réponse, choisir un verdict, saisir éventuellement un motif et un commentaire, puis enregistrer. La valeur est rechargée à la prochaine ouverture. |
| Ajouter et indexer | Ajouter `https://example.invalid/sites/demo/documents` dans la recherche documentaire. Après l’indexation, la case permet d’inclure la source dans la recherche. L’URL `https://example.invalid/sites/demo/dossier-inaccessible` simule un échec. |
| Mémoire | « Reprendre un sujet » rouvre un fil et envoie la demande d’actualisation. « Effacer les échanges » exige une confirmation et crée une nouvelle discussion. |

`npm run build:demo` génère la version statique de démonstration. `npm run build` prépare la version pour l’API réelle dans `dist/assistant-chat/browser`. Les commandes servent deux configurations explicites.

## Contrat proposé à l’API Python

`src/app/api/chat.models.ts` définit les objets transmis et `src/app/api/chat-api.ts` contient les méthodes de raccordement. L’API est attendue sous `/api`, sur la même origine que le front. Pour un essai en développement avec un serveur séparé, `npm run start:api -- --proxy-config <fichier-proxy>` utilise le proxy de développement Angular.

| Requête | Entrée HTTP | Réponse | Appel Python prévu |
| --- | --- | --- | --- |
| `GET /api/me` | | `SessionProfile` | `get_context(...)` et `Access.user_context(uid)` |
| `GET /api/conversations` | | `Conversation[]`, la plus récente en premier | `Store.conversations(uid)` |
| `POST /api/conversations` | `{}` | `Conversation` | `Store.new_conversation(uid)` |
| `GET /api/conversations/{cid}/messages` | | `ChatMessage[]`, ordre chronologique | `Access.visible_messages(uid, cid)`, `source_link(...)`, `Store.run_for_message(uid, message_id)` |
| `POST /api/conversations/{cid}/turns` | `{ "question": "…" }` | Flux `TurnEvent` | `ask(..., uid, cid, question, profile_enabled=..., on_progress=...)` |
| `GET /api/conversations/{cid}/skills` | | `SkillState` | `get_skill_state(...)` |
| `PATCH /api/conversations/{cid}/skills` | Un `SkillChange` | `SkillState` actualisé | `set_document_search(...)`, `set_verification(...)` ou `select_source(...)` |
| `POST /api/conversations/{cid}/sources` | `{ "url": "…" }` | `SkillState` avec le nouveau `source_id` et son `job_id` | `enqueue_source_sync(...)` avec `Synchronizer.index_from_chat`, puis `get_skill_state(...)` |
| `GET /api/conversations/{cid}/source-jobs/{jobId}` | | `SourceJob` | `get_source_job(...)` |
| `GET /api/conversations/{cid}/messages/{messageId}/feedback` | | `ResponseFeedback` ou JSON `null` | `Store.run_for_message(...)`, puis `Store.feedback(uid, run_id)` |
| `PUT /api/conversations/{cid}/messages/{messageId}/feedback` | `ResponseFeedback` | `FeedbackReceipt` | `Store.save_feedback(uid, run_id, …)` puis `export_run(...)` |
| `GET /api/conversations/suggestions` | | `Suggestion[]`, comprenant la question d’actualisation | `Access.suggestions(uid)` et préparation de la question |
| `DELETE /api/conversations` | | `Conversation` pour la nouvelle discussion | `Store.forget(uid)` puis `Store.new_conversation(uid)` |

- Le serveur résout l’identité pour chaque requête. `POC_USER_ID` est une configuration du serveur pour le POC. La carte reçoit uniquement les champs d’affichage renvoyés par `/api/me`. Un mode invité se représente par `{ "profile_enabled": false, "profile": null }`.
- Le serveur vérifie le périmètre des conversations, messages, sources et travaux d’indexation lors de leur accès. Les sources des réponses sont projetées en `{doc_id, title, url}` à partir des éléments autorisés. Le serveur fixe `can_feedback` et associe le message à son `run_id`.
- Pour l’ajout de source, la validation du périmètre autorisé et l’indexation sont prises en charge par les opérations Python existantes. La réponse contient l’état de sélection courant. `verification_required: true` indique une vérification obligatoire avec `verification: true`.
- Un échec de suivi après l’enregistrement d’un avis se représente par `{ "feedback": {...}, "tracking_warning": true }`. Une erreur HTTP transmet un objet `{ "code": "...", "message": "Libellé affichable" }` et un statut adapté.

### Flux d’un tour

Le `POST` renvoie un événement JSON par ligne en UTF-8 (`Content-Type: application/x-ndjson`). Le callback `on_progress` fournit les libellés publics. Le dernier événement confirme l’enregistrement du résultat visible ou signale une erreur.

```jsonl
{"type":"progress","label":"Recherche des sources"}
{"type":"progress","label":"Vérification de la fidélité"}
{"type":"completed"}
```

En cas d’échec après l’ouverture du flux, le dernier événement prend la forme suivante.

```jsonl
{"type":"error","code":"turn_failed","message":"Le traitement de la demande a échoué."}
```

Le front relit l’historique après le tour, y compris en cas de coupure. Un refus de vérification enregistré est une réponse visible accompagnée de `verification`, et le flux se termine par `completed`. Les événements de progression transportent seulement les libellés, et la lecture des messages fournit le contenu final. Les premiers événements doivent parvenir au navigateur avant la fin du tour pour afficher une progression continue.

## Reprise dans une autre application Angular

La page standalone `ChatPage` et ses composants sont dans `src/app/chat`. Le thème et la mise en page se trouvent dans `src/styles.css`. Le fournisseur HTTP de démonstration se trouve dans `src/app/api/chat-http.providers.demo.ts` et utilise les données de `src/app/demo`.

## Références techniques

Pondération indicative du cadrage documentaire.

- Compatibilité Angular et Node.js, 20 %. [Matrice officielle](https://angular.dev/reference/versions)
- Démarrage standalone, 15 %. [Angular bootstrapApplication](https://v20.angular.dev/api/platform-browser/bootstrapApplication)
- Contrat des requêtes HTTP, 20 %. [Angular HttpClient](https://v20.angular.dev/guide/http/making-requests)
- Lecture progressive de la réponse, 25 %. [Angular HttpDownloadProgressEvent](https://v20.angular.dev/api/common/http/HttpDownloadProgressEvent)
- Traitement du contenu affiché, 20 %. [Sécurité du rendu Angular](https://v20.angular.dev/best-practices/security)
