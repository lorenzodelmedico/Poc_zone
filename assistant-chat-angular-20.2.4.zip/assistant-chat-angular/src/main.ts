import { provideZonelessChangeDetection } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { CHAT_HTTP_PROVIDERS } from './app/api/chat-http.providers';
import { ChatPage } from './app/chat/chat-page';

bootstrapApplication(ChatPage, {
  providers: [provideZonelessChangeDetection(), ...CHAT_HTTP_PROVIDERS],
}).catch((error: unknown) => {
  console.error('Le démarrage du chat a échoué.', error);
  const root = document.querySelector('app-chat');
  if (root) {
    root.textContent = 'Le démarrage du chat a échoué.';
  }
});
