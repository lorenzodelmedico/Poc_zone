import {
  HttpErrorResponse,
  HttpEventType,
  HttpHeaders,
  HttpResponse,
  type HttpEvent,
  type HttpInterceptorFn,
} from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { concat, map, of, throwError, timer, type Observable } from 'rxjs';
import {
  FEEDBACK_REASONS,
  QUESTION_LIMIT,
  type ChatMessage,
  type ChatSource,
  type Conversation,
  type EvidenceLink,
  type FeedbackReceipt,
  type ResponseFeedback,
  type SessionProfile,
  type SkillChange,
  type SkillState,
  type SourceJob,
  type Suggestion,
  type TurnEvent,
} from '../api/chat.models';

interface DemoConversation extends Conversation {
  messages: ChatMessage[];
  skill: SkillState;
}

interface DemoJob {
  id: string;
  conversationId: string;
  queuedAt: number;
  fails: boolean;
}

interface DemoState {
  conversations: DemoConversation[];
  feedback: Record<string, ResponseFeedback>;
  jobs: DemoJob[];
}

const STORAGE_KEY = 'assistant-chat.angular.demo.v1';

const PROFILE: SessionProfile = {
  profile_enabled: true,
  profile: {
    legal_name_first_name: 'Camille',
    legal_name_last_name: 'Martin',
    position_title: 'Chargée de formation',
    natco: 'FR',
  },
};

const TRAINING_GUIDE: EvidenceLink = {
  title: 'Guide de formation · Exemple',
  doc_id: 'demo-training-guide',
  url: 'https://example.invalid/documentation/formation',
};

function emptySkill(): SkillState {
  return { revision: 0, document_search: false, verification: false, sources: [] };
}

function seed(): DemoState {
  return {
    conversations: [
      {
        conversation_id: 'demo-formation',
        title: 'Demande de formation',
        skill: { ...emptySkill(), document_search: true, verification: true },
        messages: [
          { message_id: 'training-question', role: 'user', content: 'Comment faire une demande de formation ?' },
          {
            message_id: 'training-answer',
            role: 'assistant',
            content: 'La demande de formation se prépare en trois étapes :\n\n'
              + '1. Sélectionner une formation dans le catalogue.\n'
              + '2. Renseigner le motif et les dates souhaitées.\n'
              + '3. Transmettre la demande pour validation.\n\n'
              + 'Le **statut de la demande** est ensuite visible dans l’espace de suivi.',
            sources: [TRAINING_GUIDE],
            can_feedback: true,
            verification: { status: 'verified', message: 'Fidélité aux sources vérifiée' },
          },
        ],
      },
      {
        conversation_id: 'demo-profil',
        title: 'Mon profil',
        skill: emptySkill(),
        messages: [
          { message_id: 'profile-question', role: 'user', content: 'Qui suis-je ?' },
          {
            message_id: 'profile-answer',
            role: 'assistant',
            content: '**Camille Martin**\n\nChargée de formation · FR',
            can_feedback: true,
          },
        ],
      },
    ],
    feedback: {},
    jobs: [],
  };
}

function uid(): string {
  return globalThis.crypto.randomUUID();
}

function httpFailure(status: number, code: string, message: string): HttpErrorResponse {
  return new HttpErrorResponse({ status, error: { code, message } });
}

@Injectable({ providedIn: 'root' })
class DemoBackend {
  private readonly data = this.read();

  profile(): SessionProfile {
    return PROFILE;
  }

  conversations(): Conversation[] {
    return this.data.conversations.map(({ conversation_id, title }) => ({ conversation_id, title }));
  }

  newConversation(): Conversation {
    const conversation = { conversation_id: uid(), title: 'Nouvelle discussion' };
    this.data.conversations.unshift({ ...conversation, messages: [], skill: emptySkill() });
    this.save();
    return conversation;
  }

  suggestions(): Suggestion[] {
    return this.data.conversations.flatMap(conversation => {
      const lastQuestion = conversation.messages.filter(message => message.role === 'user').at(-1);
      if (!lastQuestion) {
        return [];
      }
      return [{
        conversation_id: conversation.conversation_id,
        theme_key: conversation.conversation_id,
        title: conversation.title,
        prompt: 'Rechercher les informations actuelles pour cette demande antérieure : ' + lastQuestion.content,
      }];
    }).slice(0, 3);
  }

  forget(): Conversation {
    this.data.conversations = [];
    this.data.jobs = [];
    this.data.feedback = {};
    return this.newConversation();
  }

  messages(cid: string): ChatMessage[] {
    return this.conversation(cid).messages.slice();
  }

  skillState(cid: string): SkillState {
    const skill = this.conversation(cid).skill;
    return {
      ...skill,
      sources: skill.sources.map(source => ({
        ...source,
        status: this.sourceJob(cid, source.job_id).status,
      })),
    };
  }

  updateSkill(cid: string, change: SkillChange): SkillState {
    const skill = this.conversation(cid).skill;
    if ('document_search' in change && typeof change.document_search === 'boolean') {
      skill.document_search = change.document_search;
    } else if ('verification' in change && typeof change.verification === 'boolean') {
      skill.verification = change.verification;
    } else if ('source_id' in change && typeof change.selected === 'boolean') {
      const source = skill.sources.find(item => item.source_id === change.source_id);
      if (!source) {
        throw httpFailure(404, 'source_not_found', 'Source introuvable.');
      }
      source.selected = change.selected;
    } else {
      throw httpFailure(400, 'invalid_skill_change', 'Paramètre de skill invalide.');
    }
    skill.revision += 1;
    this.save();
    return this.skillState(cid);
  }

  addSource(cid: string, value: unknown): SkillState {
    const skill = this.conversation(cid).skill;
    let url: URL;
    try {
      if (typeof value !== 'string') {
        throw new Error('URL requise');
      }
      url = new URL(value.trim());
      if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password) {
        throw new Error('URL invalide');
      }
    } catch {
      throw httpFailure(400, 'invalid_source_url', 'Une URL HTTP ou HTTPS valide est requise.');
    }
    if (skill.sources.some(source => source.url === url.href)) {
      throw httpFailure(409, 'source_exists', 'Cette source est déjà présente dans la discussion.');
    }
    const job: DemoJob = {
      id: uid(),
      conversationId: cid,
      queuedAt: Date.now(),
      fails: url.pathname.endsWith('/dossier-inaccessible'),
    };
    const source: ChatSource = {
      source_id: uid(),
      url: url.href,
      job_id: job.id,
      selected: false,
      status: 'queued',
    };
    this.data.jobs.push(job);
    skill.sources.push(source);
    skill.revision += 1;
    this.save();
    return this.skillState(cid);
  }

  sourceJob(cid: string, jobId: string): SourceJob {
    const job = this.data.jobs.find(item => item.id === jobId && item.conversationId === cid);
    if (!job) {
      throw httpFailure(404, 'source_job_not_found', 'Travail d’indexation introuvable.');
    }
    const elapsed = Date.now() - job.queuedAt;
    if (elapsed < 1200) {
      return { job_id: jobId, status: 'queued' };
    }
    if (job.fails && elapsed >= 3000) {
      return { job_id: jobId, status: 'failed', error: 'Dossier inaccessible dans la démonstration.' };
    }
    if (elapsed < 6200) {
      return {
        job_id: jobId,
        status: 'running',
        progress: 'Indexation documentaire',
        documents_total: 6,
        documents_completed: Math.min(5, Math.floor(elapsed / 1000)),
      };
    }
    return { job_id: jobId, status: 'completed', documents_indexed: 6 };
  }

  feedback(cid: string, mid: string): ResponseFeedback | null {
    this.evaluableMessage(cid, mid);
    return this.data.feedback[mid] ?? null;
  }

  saveFeedback(cid: string, mid: string, value: ResponseFeedback): FeedbackReceipt {
    this.evaluableMessage(cid, mid);
    if (!value || typeof value.helpful !== 'boolean' || typeof value.comment !== 'string'
      || !FEEDBACK_REASONS.includes(value.reason)) {
      throw httpFailure(400, 'invalid_feedback', 'Le verdict de l’avis doit être renseigné.');
    }
    this.data.feedback[mid] = value;
    this.save();
    return { feedback: value };
  }

  ask(cid: string, input: unknown): Observable<HttpEvent<string>> {
    this.conversation(cid);
    const question = typeof input === 'string' ? input.trim() : '';
    if (!question || Array.from(question).length > QUESTION_LIMIT) {
      throw httpFailure(400, 'invalid_question', 'Une question de 1 à 8 000 caractères est requise.');
    }
    const skill = this.skillState(cid);
    const aboutProfile = /qui suis.je/i.test(question);
    const stages = ['Analyse de la demande'];
    if (!aboutProfile && skill.document_search) {
      stages.push('Recherche des sources', 'Préparation de la réponse');
      if (skill.verification) {
        stages.push('Vérification de la fidélité');
      }
    } else {
      stages.push(aboutProfile ? 'Lecture du profil' : 'Préparation de la réponse');
    }

    let responseText = '';
    const stageEvents = stages.map(label => timer(350).pipe(map((): HttpEvent<string> => {
      const event: TurnEvent = { type: 'progress', label };
      responseText += JSON.stringify(event) + '\n';
      return {
        type: HttpEventType.DownloadProgress,
        partialText: responseText,
        loaded: new TextEncoder().encode(responseText).byteLength,
      };
    })));
    const completed = timer(250).pipe(map(() => {
      const conversation = this.conversation(cid);
      const reply = this.answer(question, skill, aboutProfile);
      conversation.messages.push({ message_id: uid(), role: 'user', content: question }, reply);
      if (conversation.messages.length === 2) {
        const characters = Array.from(question);
        conversation.title = characters.length > 64 ? characters.slice(0, 63).join('') + '…' : question;
      }
      this.data.conversations = [
        conversation,
        ...this.data.conversations.filter(item => item.conversation_id !== cid),
      ];
      this.save();
      const terminal: TurnEvent = { type: 'completed' };
      return new HttpResponse<string>({
        body: responseText + JSON.stringify(terminal) + '\n',
        headers: new HttpHeaders({ 'Content-Type': 'application/x-ndjson' }),
      });
    }));
    return concat(of<HttpEvent<string>>({ type: HttpEventType.Sent }), ...stageEvents, completed);
  }

  private answer(question: string, skill: SkillState, aboutProfile: boolean): ChatMessage {
    const message: ChatMessage = {
      message_id: uid(),
      role: 'assistant',
      can_feedback: true,
      content: '',
    };
    if (aboutProfile) {
      return { ...message, content: '**Camille Martin**\n\nChargée de formation · FR' };
    }
    if (!skill.document_search) {
      return { ...message, content: 'La recherche documentaire est désactivée pour cette discussion.'
        + ' Le panneau **Recherche documentaire** permet de l’activer dans la démonstration.' };
    }
    const selected = skill.sources.filter(source => source.selected);
    const ready = selected.filter(source => source.status === 'completed');
    if (selected.length && !ready.length) {
      return {
        ...message,
        content: 'Les sources sélectionnées sont indisponibles pour la recherche.',
        verification: { status: 'not_applicable', message: 'Source sélectionnée indisponible' },
      };
    }
    if (skill.verification && /(?:démo|démonstration) refus/i.test(question)) {
      return {
        ...message,
        content: 'Les sources disponibles ne permettent pas d’étayer une réponse à cette question.',
        verification: { status: 'refused', message: 'Preuves insuffisantes' },
      };
    }
    if (ready.length) {
      message.sources = ready.map(source => ({
        doc_id: source.source_id,
        title: 'Source indexée · Exemple',
        url: source.url,
      }));
      message.content = 'La recherche a utilisé les **sources sélectionnées** pour cette discussion.'
        + '\n\nCe résultat illustre la restitution des sources après indexation.';
    } else {
      message.sources = [TRAINING_GUIDE];
      message.content = 'Le guide de formation présente les étapes de **création**, de **validation**'
        + ' et de **suivi** d’une demande.\n\n'
        + 'Le statut *En attente de validation* indique que la demande a été transmise. '
        + '<orig lang="en" text="Pending approval">';
    }
    if (skill.verification) {
      message.verification = { status: 'verified', message: 'Fidélité aux sources vérifiée' };
    }
    return message;
  }

  private conversation(cid: string): DemoConversation {
    const conversation = this.data.conversations.find(item => item.conversation_id === cid);
    if (!conversation) {
      throw httpFailure(404, 'conversation_not_found', 'Conversation introuvable.');
    }
    return conversation;
  }

  private evaluableMessage(cid: string, mid: string): void {
    if (!this.conversation(cid).messages.some(message => message.message_id === mid && message.can_feedback)) {
      throw httpFailure(404, 'feedback_message_not_found', 'Cette réponse ne peut pas être évaluée.');
    }
  }

  private read(): DemoState {
    try {
      const stored = sessionStorage.getItem(STORAGE_KEY);
      if (stored) {
        const data = JSON.parse(stored) as DemoState;
        if (Array.isArray(data.conversations) && Array.isArray(data.jobs) && data.feedback) {
          return data;
        }
      }
    } catch {
      // Browser storage is optional for the synthetic demo.
    }
    return seed();
  }

  private save(): void {
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
    } catch {
      // The demo still functions in memory.
    }
  }
}

export const demoInterceptor: HttpInterceptorFn = (request, next) => {
  if (!request.url.startsWith('/api/')) {
    return next(request);
  }
  const backend = inject(DemoBackend);
  const json = (body: unknown) => of(new HttpResponse({ body }));
  const { method } = request;
  try {
    const parts = request.url.slice('/api/'.length).split('/').map(decodeURIComponent);
    if (parts.length === 1 && parts[0] === 'me' && method === 'GET') {
      return json(backend.profile());
    }
    const [resource, cid, action, id, subAction] = parts;
    if (resource === 'conversations') {
      if (parts.length === 1) {
        if (method === 'GET') return json(backend.conversations());
        if (method === 'POST') return json(backend.newConversation());
        if (method === 'DELETE') return json(backend.forget());
      }
      if (parts.length === 2 && cid === 'suggestions' && method === 'GET') {
        return json(backend.suggestions());
      }
      if (parts.length === 3) {
        if (action === 'messages' && method === 'GET') return json(backend.messages(cid));
        if (action === 'turns' && method === 'POST') return backend.ask(cid, (request.body as { question?: string })?.question);
        if (action === 'skills' && method === 'GET') return json(backend.skillState(cid));
        if (action === 'skills' && method === 'PATCH') return json(backend.updateSkill(cid, request.body as SkillChange));
        if (action === 'sources' && method === 'POST') return json(backend.addSource(cid, (request.body as { url?: string })?.url));
      }
      if (parts.length === 4 && action === 'source-jobs' && method === 'GET') {
        return json(backend.sourceJob(cid, id));
      }
      if (parts.length === 5 && action === 'messages' && subAction === 'feedback') {
        if (method === 'GET') return json(backend.feedback(cid, id));
        if (method === 'PUT') return json(backend.saveFeedback(cid, id, request.body as ResponseFeedback));
      }
    }
    throw httpFailure(404, 'route_not_found', 'Route de démonstration introuvable.');
  } catch (error: unknown) {
    return throwError(() => error);
  }
};
