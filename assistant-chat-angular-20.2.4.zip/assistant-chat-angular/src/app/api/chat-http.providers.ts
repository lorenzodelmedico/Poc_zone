import { provideHttpClient } from '@angular/common/http';

export const CHAT_HTTP_PROVIDERS = [provideHttpClient()];
