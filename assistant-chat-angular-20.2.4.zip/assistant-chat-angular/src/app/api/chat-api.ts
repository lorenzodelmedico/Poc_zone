import { HttpClient, HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { inject, Injectable, InjectionToken } from '@angular/core';
import { firstValueFrom, lastValueFrom, tap } from 'rxjs';
import type { ChatMessage, Conversation, FeedbackReceipt, ResponseFeedback, SessionProfile, SkillChange, SkillState, SourceJob, Suggestion } from './chat.models';
import { ChatApiError, TurnStream } from './turn-stream';

const API = '/api';
export const CHAT_DEMO = new InjectionToken<boolean>('CHAT_DEMO', { factory: () => false });

@Injectable({ providedIn: 'root' })
export class ChatApi {
  private readonly http = inject(HttpClient);

  userContext(): Promise<SessionProfile> {
    return firstValueFrom(this.http.get<SessionProfile>(API + '/me'));
  }

  conversations(): Promise<Conversation[]> {
    return firstValueFrom(this.http.get<Conversation[]>(API + '/conversations'));
  }

  newConversation(): Promise<Conversation> {
    return firstValueFrom(this.http.post<Conversation>(API + '/conversations', {}));
  }

  visibleMessages(cid: string): Promise<ChatMessage[]> {
    return firstValueFrom(this.http.get<ChatMessage[]>(this.conversationPath(cid) + '/messages'));
  }

  async ask(cid: string, question: string, onProgress: (label: string) => void): Promise<void> {
    const stream = new TurnStream(onProgress);
    await lastValueFrom(this.http.post(this.conversationPath(cid) + '/turns', { question }, {
      observe: 'events',
      responseType: 'text',
      reportProgress: true,
      headers: { Accept: 'application/x-ndjson' },
    }).pipe(tap(event => {
      if (event.type === HttpEventType.DownloadProgress && event.partialText !== undefined) {
        stream.read(event.partialText);
      } else if (event.type === HttpEventType.Response) {
        stream.read(event.body ?? '', true);
      }
    })));
    stream.finish();
  }

  getSkillState(cid: string): Promise<SkillState> {
    return firstValueFrom(this.http.get<SkillState>(this.conversationPath(cid) + '/skills'));
  }

  setDocumentSearch(cid: string, enabled: boolean): Promise<SkillState> {
    return this.updateSkill(cid, { document_search: enabled });
  }

  setVerification(cid: string, enabled: boolean): Promise<SkillState> {
    return this.updateSkill(cid, { verification: enabled });
  }

  selectSource(cid: string, sourceId: string, selected: boolean): Promise<SkillState> {
    return this.updateSkill(cid, { source_id: sourceId, selected });
  }

  enqueueSourceSync(cid: string, url: string): Promise<SkillState> {
    return firstValueFrom(this.http.post<SkillState>(this.conversationPath(cid) + '/sources', { url }));
  }

  getSourceJob(cid: string, jobId: string): Promise<SourceJob> {
    return firstValueFrom(this.http.get<SourceJob>(this.conversationPath(cid) + '/source-jobs/' + encodeURIComponent(jobId)));
  }

  feedback(cid: string, messageId: string): Promise<ResponseFeedback | null> {
    return firstValueFrom(this.http.get<ResponseFeedback | null>(this.feedbackPath(cid, messageId)));
  }

  saveFeedback(cid: string, messageId: string, feedback: ResponseFeedback): Promise<FeedbackReceipt> {
    return firstValueFrom(this.http.put<FeedbackReceipt>(this.feedbackPath(cid, messageId), feedback));
  }

  suggestions(): Promise<Suggestion[]> {
    return firstValueFrom(this.http.get<Suggestion[]>(API + '/conversations/suggestions'));
  }

  forget(): Promise<Conversation> {
    return firstValueFrom(this.http.delete<Conversation>(API + '/conversations'));
  }

  private updateSkill(cid: string, change: SkillChange): Promise<SkillState> {
    return firstValueFrom(this.http.patch<SkillState>(this.conversationPath(cid) + '/skills', change));
  }

  private conversationPath(cid: string): string {
    return API + '/conversations/' + encodeURIComponent(cid);
  }

  private feedbackPath(cid: string, messageId: string): string {
    return this.conversationPath(cid) + '/messages/' + encodeURIComponent(messageId) + '/feedback';
  }
}

export function publicError(error: unknown, fallback: string): string {
  if (error instanceof ChatApiError) {
    return error.message;
  }
  if (!(error instanceof HttpErrorResponse)) {
    return fallback;
  }
  if (error.status === 0) {
    return 'La connexion a été interrompue.';
  }
  if (error.status === 401) {
    return 'La session est expirée ou indisponible.';
  }
  if (error.status === 403) {
    return 'Cette action est hors du périmètre autorisé.';
  }
  let body: unknown = error.error;
  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch {
      return fallback;
    }
  }
  if (body && typeof body === 'object' && 'code' in body && typeof body.code === 'string'
    && 'message' in body && typeof body.message === 'string') {
    return body.message;
  }
  return fallback;
}
