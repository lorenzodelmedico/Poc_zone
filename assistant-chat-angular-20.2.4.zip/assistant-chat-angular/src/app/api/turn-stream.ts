import type { TurnEvent } from './chat.models';

type TerminalEvent = Exclude<TurnEvent, { type: 'progress' }>;

export class ChatApiError extends Error {
  constructor(readonly code: string, message: string) {
    super(message);
  }
}

export class TurnStream {
  private offset = 0;
  private pending = '';
  private terminal?: TerminalEvent;

  constructor(private readonly onProgress: (label: string) => void) {}

  read(responseText: string, final = false): void {
    if (responseText.length < this.offset) {
      throw this.invalidStream();
    }
    const data = this.pending + responseText.slice(this.offset);
    this.offset = responseText.length;
    const lines = data.split('\n');
    this.pending = final ? '' : (lines.pop() ?? '');
    for (const line of lines) {
      if (line.trim()) {
        this.handleLine(line);
      }
    }
  }

  finish(): void {
    if (this.terminal?.type === 'error') {
      throw new ChatApiError(this.terminal.code, this.terminal.message);
    }
    if (!this.terminal) {
      throw this.invalidStream();
    }
  }

  private handleLine(line: string): void {
    if (this.terminal) {
      throw this.invalidStream();
    }
    let parsed: unknown;
    try {
      parsed = JSON.parse(line);
    } catch {
      throw this.invalidStream();
    }
    if (!parsed || typeof parsed !== 'object' || !('type' in parsed)) {
      throw this.invalidStream();
    }
    if (parsed.type === 'progress' && 'label' in parsed && typeof parsed.label === 'string') {
      this.onProgress(parsed.label);
    } else if (parsed.type === 'completed') {
      this.terminal = { type: 'completed' };
    } else if (parsed.type === 'error' && 'code' in parsed && typeof parsed.code === 'string'
      && 'message' in parsed && typeof parsed.message === 'string') {
      this.terminal = { type: 'error', code: parsed.code, message: parsed.message };
    } else {
      throw this.invalidStream();
    }
  }

  private invalidStream(): ChatApiError {
    return new ChatApiError('invalid_turn_stream', 'Le traitement a été interrompu avant sa confirmation.');
  }
}
