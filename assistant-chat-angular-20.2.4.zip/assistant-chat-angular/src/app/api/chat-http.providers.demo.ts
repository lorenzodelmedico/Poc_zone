import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { CHAT_DEMO } from './chat-api';
import { demoInterceptor } from '../demo/demo-interceptor';

export const CHAT_HTTP_PROVIDERS = [
  provideHttpClient(withInterceptors([demoInterceptor])),
  { provide: CHAT_DEMO, useValue: true },
];
