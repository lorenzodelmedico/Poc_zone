export interface Profile {
  legal_name_first_name?: string | null;
  legal_name_last_name?: string | null;
  natco?: string | null;
  position_title?: string | null;
  position?: string | null;
  dateofbirth?: string | null;
}

export interface SessionProfile {
  profile_enabled: boolean;
  profile: Profile | null;
}

export interface Conversation {
  conversation_id: string;
  title: string;
}

export interface Suggestion {
  conversation_id: string;
  theme_key: string;
  title: string;
  description?: string;
  prompt: string;
}

export interface EvidenceLink {
  doc_id: string;
  title: string;
  url: string | null;
}

export interface VerificationNotice {
  status: 'verified' | 'refused' | 'error' | 'not_applicable';
  message: string;
}

export interface ChatMessage {
  message_id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: EvidenceLink[];
  can_feedback?: boolean;
  verification?: VerificationNotice;
}

export const FEEDBACK_REASONS = [
  '',
  'Information fausse',
  'Information manquante',
  'Mauvaise source',
  'Lien inutilisable',
  'Autre',
] as const;

export interface ResponseFeedback {
  helpful: boolean;
  reason: (typeof FEEDBACK_REASONS)[number];
  comment: string;
}

export interface FeedbackReceipt {
  feedback: ResponseFeedback;
  tracking_warning?: boolean;
}

export type JobStatus = 'queued' | 'running' | 'completed' | 'failed';

export interface SourceJob {
  job_id: string;
  status: JobStatus;
  progress?: string;
  documents_total?: number;
  documents_completed?: number;
  documents_indexed?: number;
  error?: string;
}

export interface ChatSource {
  source_id: string;
  job_id: string;
  url: string;
  selected: boolean;
  status: JobStatus;
}

export interface SkillState {
  revision: number;
  document_search: boolean;
  verification: boolean;
  verification_required?: boolean;
  sources: ChatSource[];
}

export type SkillChange =
  | { document_search: boolean }
  | { verification: boolean }
  | { source_id: string; selected: boolean };

export type TurnEvent =
  | { type: 'progress'; label: string }
  | { type: 'completed' }
  | { type: 'error'; code: string; message: string };

export const QUESTION_LIMIT = 8000;
