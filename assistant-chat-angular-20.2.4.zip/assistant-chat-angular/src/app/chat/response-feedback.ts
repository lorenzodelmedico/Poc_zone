import { ChangeDetectionStrategy, Component, inject, input, signal } from '@angular/core';
import { ChatApi, publicError } from '../api/chat-api';
import { FEEDBACK_REASONS, type ResponseFeedback } from '../api/chat.models';

@Component({
  selector: 'app-response-feedback',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './response-feedback.html',
})
export class ResponseFeedbackView {
  private readonly api = inject(ChatApi);

  readonly conversationId = input.required<string>();
  readonly messageId = input.required<string>();
  readonly reasons = FEEDBACK_REASONS;
  readonly loaded = signal(false);
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly helpful = signal<boolean | null>(null);
  readonly reason = signal<ResponseFeedback['reason']>('');
  readonly comment = signal('');
  readonly error = signal('');
  readonly notice = signal('');

  async load(): Promise<void> {
    if (this.loaded() || this.loading()) {
      return;
    }
    this.loading.set(true);
    this.error.set('');
    try {
      const feedback = await this.api.feedback(this.conversationId(), this.messageId());
      if (feedback) {
        this.helpful.set(feedback.helpful);
        this.reason.set(feedback.reason);
        this.comment.set(feedback.comment);
      }
      this.loaded.set(true);
    } catch (error: unknown) {
      this.error.set(publicError(error, 'L’avis enregistré est indisponible.'));
    } finally {
      this.loading.set(false);
    }
  }

  setReason(reason: string): void {
    const choice = this.reasons.find(option => option === reason);
    if (choice !== undefined) {
      this.reason.set(choice);
    }
  }

  async submit(event: Event): Promise<void> {
    event.preventDefault();
    const helpful = this.helpful();
    if (!this.loaded() || this.saving() || helpful === null) {
      return;
    }
    this.saving.set(true);
    this.error.set('');
    this.notice.set('');
    try {
      const receipt = await this.api.saveFeedback(this.conversationId(), this.messageId(), {
        helpful,
        reason: this.reason(),
        comment: this.comment(),
      });
      this.helpful.set(receipt.feedback.helpful);
      this.reason.set(receipt.feedback.reason);
      this.comment.set(receipt.feedback.comment);
      this.notice.set(receipt.tracking_warning
        ? 'Avis enregistré. Le suivi des évaluations est indisponible.'
        : 'Avis enregistré.');
    } catch (error: unknown) {
      this.error.set(publicError(error, 'Enregistrement de l’avis impossible.'));
    } finally {
      this.saving.set(false);
    }
  }
}
