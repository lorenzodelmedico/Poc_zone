import { ChangeDetectionStrategy, Component, inject, input, signal, type OnChanges, type OnDestroy, type SimpleChanges } from '@angular/core';
import { ChatApi, publicError } from '../api/chat-api';
import type { ChatSource, SkillState, SourceJob } from '../api/chat.models';

@Component({
  selector: 'app-document-skills',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './document-skills.html',
})
export class DocumentSkills implements OnChanges, OnDestroy {
  private readonly api = inject(ChatApi);
  private scope = 0;
  private timer?: ReturnType<typeof setTimeout>;
  private pollingScope?: number;

  readonly conversationId = input.required<string>();
  readonly turnRunning = input(false);
  readonly skill = signal<SkillState | null>(null);
  readonly jobs = signal(new Map<string, SourceJob>());
  readonly unreadable = signal(new Set<string>());
  readonly url = signal('');
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly error = signal('');

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['conversationId']) {
      this.stopPolling();
      this.skill.set(null);
      this.jobs.set(new Map());
      this.unreadable.set(new Set());
      this.url.set('');
      this.saving.set(false);
      void this.load();
    }
  }

  ngOnDestroy(): void {
    this.stopPolling();
  }

  async load(): Promise<void> {
    const scope = this.scope;
    this.loading.set(true);
    this.error.set('');
    this.unreadable.set(new Set());
    try {
      const skill = await this.api.getSkillState(this.conversationId());
      if (scope === this.scope) {
        this.skill.set(skill);
        this.schedulePoll();
      }
    } catch (error: unknown) {
      if (scope === this.scope) {
        this.error.set(publicError(error, 'Les paramètres documentaires sont indisponibles.'));
      }
    } finally {
      if (scope === this.scope) {
        this.loading.set(false);
      }
    }
  }

  setDocumentSearch(input: HTMLInputElement, skill: SkillState): void {
    const value = input.checked;
    input.checked = skill.document_search;
    void this.change(() => this.api.setDocumentSearch(this.conversationId(), value));
  }

  setVerification(input: HTMLInputElement, skill: SkillState): void {
    const value = input.checked;
    input.checked = skill.verification;
    void this.change(() => this.api.setVerification(this.conversationId(), value));
  }

  selectSource(input: HTMLInputElement, source: ChatSource): void {
    const value = input.checked;
    input.checked = source.selected;
    void this.change(() => this.api.selectSource(this.conversationId(), source.source_id, value));
  }

  async add(event: Event): Promise<void> {
    event.preventDefault();
    const url = this.url().trim();
    try {
      const parsed = new URL(url);
      if (!['https:', 'http:'].includes(parsed.protocol) || parsed.username || parsed.password) {
        throw new Error('invalid URL');
      }
    } catch {
      this.error.set('Une URL HTTP ou HTTPS valide est requise.');
      return;
    }
    if (await this.change(() => this.api.enqueueSourceSync(this.conversationId(), url))) {
      this.url.set('');
    }
  }

  private async change(request: () => Promise<SkillState>): Promise<boolean> {
    if (this.saving() || this.loading() || this.turnRunning()) {
      return false;
    }
    const scope = this.scope;
    this.saving.set(true);
    this.error.set('');
    try {
      const state = await request();
      if (scope !== this.scope) {
        return false;
      }
      this.skill.set(state);
      this.schedulePoll();
      return true;
    } catch (error: unknown) {
      if (scope === this.scope) {
        this.error.set(publicError(error, 'Modification des paramètres impossible.'));
      }
      return false;
    } finally {
      if (scope === this.scope) {
        this.saving.set(false);
      }
    }
  }

  private pollable(): ChatSource[] {
    return (this.skill()?.sources ?? []).filter(source => {
      const job = this.jobs().get(source.job_id);
      return !this.unreadable().has(source.job_id) && (!job || job.status === 'queued' || job.status === 'running');
    });
  }

  private schedulePoll(): void {
    if (this.timer !== undefined || this.pollingScope === this.scope || !this.pollable().length) {
      return;
    }
    this.timer = setTimeout(() => {
      this.timer = undefined;
      void this.poll();
    }, 1000);
  }

  private async poll(): Promise<void> {
    const scope = this.scope;
    const cid = this.conversationId();
    this.pollingScope = scope;
    const results = await Promise.all(this.pollable().map(async source => {
      try {
        return { id: source.job_id, job: await this.api.getSourceJob(cid, source.job_id) };
      } catch {
        return { id: source.job_id, job: null };
      }
    }));
    if (scope !== this.scope) {
      return;
    }
    const jobs = new Map(this.jobs());
    const unreadable = new Set(this.unreadable());
    for (const { id, job } of results) {
      if (job) {
        jobs.set(id, job);
      } else {
        unreadable.add(id);
      }
    }
    this.jobs.set(jobs);
    this.unreadable.set(unreadable);
    this.pollingScope = undefined;
    this.schedulePoll();
  }

  private stopPolling(): void {
    this.scope += 1;
    clearTimeout(this.timer);
    this.timer = undefined;
    this.pollingScope = undefined;
  }
}
