import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { Marked } from 'marked';
import type { ChatMessage, EvidenceLink } from '../api/chat.models';
import { ResponseFeedbackView } from './response-feedback';

type AnswerPart =
  | { kind: 'markdown'; html: string }
  | { kind: 'original'; lang: string; text: string };

const markdown = new Marked({
  renderer: {
    html: token => escapeHtml(token.text),
    image: token => escapeHtml(token.text),
  },
});

function escapeHtml(text: string): string {
  return text.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}

function originalText(text: string): string {
  return text.replaceAll('&quot;', '"').replaceAll('&apos;', "'").replaceAll('&#39;', "'")
    .replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&amp;', '&');
}

function renderAnswer(text: string): AnswerPart[] {
  const marker = /<orig\s+lang=(?:"([^"]*)"|'([^']*)')\s+text=(?:"([^"]*)"|'([^']*)')\s*\/?>\s*(?:<\/orig>)?/g;
  const parts: AnswerPart[] = [];
  let offset = 0;
  const appendMarkdown = (fragment: string) => {
    if (fragment.trim()) {
      parts.push({ kind: 'markdown', html: markdown.parse(fragment, { async: false }) });
    }
  };
  for (const match of text.matchAll(marker)) {
    appendMarkdown(text.slice(offset, match.index));
    parts.push({
      kind: 'original',
      lang: originalText(match[1] ?? match[2]),
      text: originalText(match[3] ?? match[4]),
    });
    offset = match.index + match[0].length;
  }
  appendMarkdown(text.slice(offset));
  return parts;
}

function linkUrl(value: string | null): string | null {
  if (!value) {
    return null;
  }
  try {
    const url = new URL(value);
    return ['https:', 'http:'].includes(url.protocol) && !url.username && !url.password
      ? url.href
      : null;
  } catch {
    return null;
  }
}

@Component({
  selector: 'app-message',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ResponseFeedbackView],
  templateUrl: './message-view.html',
})
export class MessageView {
  readonly message = input.required<ChatMessage>();
  readonly conversationId = input.required<string>();
  readonly parts = computed(() => this.message().role === 'assistant' ? renderAnswer(this.message().content) : []);

  readonly sources = computed(() => {
    const unique = new Map<string, EvidenceLink>();
    for (const source of this.message().sources ?? []) {
      if (!unique.has(source.doc_id)) {
        unique.set(source.doc_id, { ...source, url: linkUrl(source.url) });
      }
    }
    return [...unique.values()];
  });
}
