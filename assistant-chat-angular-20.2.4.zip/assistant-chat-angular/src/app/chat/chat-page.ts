import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  afterEveryRender,
  computed,
  inject,
  signal,
  viewChild,
  type OnInit,
} from '@angular/core';
import { CHAT_DEMO, ChatApi, publicError } from '../api/chat-api';
import { QUESTION_LIMIT, type ChatMessage, type Conversation, type SessionProfile, type Suggestion } from '../api/chat.models';
import { DocumentSkills } from './document-skills';
import { MessageView } from './message-view';

interface PendingTurn {
  question: string;
  steps: string[];
}

@Component({
  selector: 'app-chat',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DocumentSkills, MessageView],
  templateUrl: './chat-page.html',
})
export class ChatPage implements OnInit {
  private readonly api = inject(ChatApi);
  private readonly thread = viewChild<ElementRef<HTMLDivElement>>('thread');
  private readonly resumeDialog = viewChild<ElementRef<HTMLDialogElement>>('resumeDialog');
  private messageRequest = 0;
  private scrollPending = false;

  readonly demo = inject(CHAT_DEMO);
  readonly session = signal<SessionProfile | null>(null);
  readonly conversations = signal<Conversation[]>([]);
  readonly activeId = signal<string | null>(null);
  readonly messages = signal<ChatMessage[]>([]);
  readonly draft = signal('');
  readonly pending = signal<PendingTurn | null>(null);
  readonly booting = signal(false);
  readonly loadingMessages = signal(false);
  readonly savingHistory = signal(false);
  readonly bootError = signal('');
  readonly historyError = signal('');
  readonly readError = signal('');
  readonly turnError = signal('');
  readonly navOpen = signal(false);
  readonly confirmForget = signal(false);
  readonly suggestions = signal<Suggestion[] | null>(null);
  readonly loadingSuggestions = signal(false);

  readonly current = computed(() => this.conversations().find(c => c.conversation_id === this.activeId()));
  readonly profile = computed(() => this.session()?.profile ?? null);
  readonly profileLabel = computed(() => {
    const profile = this.profile();
    const name = [profile?.legal_name_first_name, profile?.legal_name_last_name].filter(Boolean).join(' ');
    return name || (this.session()?.profile_enabled === false ? 'Invité' : 'Profil');
  });
  readonly initials = computed(() => this.profileLabel().split(' ').slice(0, 2).map(word => word[0]).join('').toUpperCase());
  readonly tooLong = computed(() => Array.from(this.draft()).length > QUESTION_LIMIT);
  readonly canSend = computed(() => !!this.activeId() && !this.pending() && !this.loadingMessages()
    && !this.savingHistory() && !this.readError());

  constructor() {
    afterEveryRender({
      mixedReadWrite: () => {
        const viewport = this.thread()?.nativeElement;
        if (this.scrollPending && viewport) {
          this.scrollPending = false;
          viewport.scrollTop = viewport.scrollHeight;
        }
        const dialog = this.resumeDialog()?.nativeElement;
        if (dialog && !dialog.open) {
          dialog.showModal();
        }
      },
    });
  }

  ngOnInit(): void {
    void this.load();
  }

  async load(): Promise<void> {
    if (this.booting()) {
      return;
    }
    this.booting.set(true);
    this.bootError.set('');
    try {
      const [session, conversations] = await Promise.all([this.api.userContext(), this.api.conversations()]);
      this.session.set(session);
      this.conversations.set(conversations);
      const first = conversations[0] ?? await this.api.newConversation();
      this.keepConversation(first);
      await this.openConversation(first.conversation_id);
    } catch (error: unknown) {
      this.bootError.set(publicError(error, 'L’assistant est indisponible.'));
    } finally {
      this.booting.set(false);
    }
  }

  async openConversation(cid: string): Promise<void> {
    if (this.pending()) {
      return;
    }
    if (this.activeId() !== cid) {
      this.messages.set([]);
      this.draft.set('');
      this.turnError.set('');
    }
    this.activeId.set(cid);
    this.navOpen.set(false);
    await this.readMessages(cid);
  }

  async newConversation(): Promise<void> {
    if (this.savingHistory() || this.pending()) {
      return;
    }
    this.savingHistory.set(true);
    this.historyError.set('');
    try {
      const conversation = await this.api.newConversation();
      this.keepConversation(conversation);
      await this.openConversation(conversation.conversation_id);
    } catch (error: unknown) {
      this.historyError.set(publicError(error, 'Création de la discussion impossible.'));
    } finally {
      this.savingHistory.set(false);
    }
  }

  async forget(): Promise<void> {
    if (!this.confirmForget() || this.savingHistory() || this.pending()) {
      return;
    }
    this.savingHistory.set(true);
    this.historyError.set('');
    try {
      const conversation = await this.api.forget();
      this.conversations.set([conversation]);
      this.suggestions.set(null);
      this.confirmForget.set(false);
      await this.openConversation(conversation.conversation_id);
    } catch (error: unknown) {
      this.historyError.set(publicError(error, 'Effacement des échanges impossible.'));
    } finally {
      this.savingHistory.set(false);
    }
  }

  async showSuggestions(): Promise<void> {
    if (this.loadingSuggestions() || this.pending()) {
      return;
    }
    this.historyError.set('');
    this.loadingSuggestions.set(true);
    try {
      this.suggestions.set((await this.api.suggestions()).slice(0, 3));
    } catch (error: unknown) {
      this.historyError.set(publicError(error, 'Sujets précédents indisponibles.'));
    } finally {
      this.loadingSuggestions.set(false);
    }
  }

  async resume(suggestion: Suggestion): Promise<void> {
    if (this.pending() || this.savingHistory()) {
      return;
    }
    this.suggestions.set(null);
    await this.openConversation(suggestion.conversation_id);
    if (this.activeId() === suggestion.conversation_id) {
      await this.send(suggestion.prompt);
    }
  }

  submit(event: Event): void {
    event.preventDefault();
    void this.send();
  }

  onComposerKey(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      void this.send();
    }
  }

  private async send(input = this.draft()): Promise<void> {
    const cid = this.activeId();
    const question = input.trim();
    if (!cid || !this.canSend() || !question) {
      return;
    }
    if (Array.from(input).length > QUESTION_LIMIT) {
      this.turnError.set('Question supérieure à 8 000 caractères.');
      return;
    }
    const previousIds = new Set(this.messages().map(message => message.message_id));
    this.pending.set({ question, steps: [] });
    this.draft.set('');
    this.turnError.set('');
    this.scrollPending = true;
    let failed = false;
    try {
      await this.api.ask(cid, question, label => {
        this.pending.update(turn => turn && { ...turn, steps: [...turn.steps, label] });
        this.scrollPending = true;
      });
    } catch (error: unknown) {
      failed = true;
      this.turnError.set(publicError(error, 'Le traitement de la demande a été interrompu.'));
    }
    const messages = await this.readMessages(cid);
    if (failed && messages && !messages.some(message => message.role === 'user'
      && !previousIds.has(message.message_id) && message.content === question)) {
      this.draft.set(question);
    }
    this.savingHistory.set(true);
    this.pending.set(null);
    try {
      this.conversations.set(await this.api.conversations());
    } catch {
      this.historyError.set('Actualisation de la liste des conversations indisponible.');
    } finally {
      this.savingHistory.set(false);
    }
  }

  private async readMessages(cid: string): Promise<ChatMessage[] | null> {
    const request = ++this.messageRequest;
    this.loadingMessages.set(true);
    this.readError.set('');
    try {
      const messages = await this.api.visibleMessages(cid);
      if (request !== this.messageRequest) {
        return null;
      }
      this.messages.set(messages);
      this.scrollPending = true;
      return messages;
    } catch (error: unknown) {
      if (request === this.messageRequest) {
        this.readError.set(publicError(error, 'Le fil de discussion est indisponible.'));
      }
      return null;
    } finally {
      if (request === this.messageRequest) {
        this.loadingMessages.set(false);
      }
    }
  }

  private keepConversation(conversation: Conversation): void {
    this.conversations.update(current => current.some(item => item.conversation_id === conversation.conversation_id)
      ? current
      : [conversation, ...current]);
  }
}
