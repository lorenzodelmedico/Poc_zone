# Remplacer execute() et ask() dans app/agent.py. Les imports à ajouter sont
# indiqués dans MODIFICATIONS.md ; les autres helpers existants sont conservés.

async def execute(settings, store, api, user_id, question, *, kind='evaluation', mode='full',
                  prompt_variant='actuel', document_ids=None, sections=None,
                  cid=None, current_message_id=None, profile_enabled=True, on_progress=None):
    if mode not in {'full', 'selected'} or prompt_variant not in PROMPTS:
        raise ValueError('Mode ou prompt inconnu.')
    question = question.strip()
    if not question or len(question) > 8000:
        raise ValueError('Question vide ou supérieure à 8 000 caractères.')
    selection = {'document_ids': document_ids or [], 'sections': sections or {}}
    rid = store.start_answer_run(user_id, kind, mode, prompt_variant, question, selection, cid)
    started = time.perf_counter()
    steps = []
    result = {'run_id': rid, 'model': os.getenv('LLM_MODEL', ''),
              'prompt_hash': digest(PROMPTS[prompt_variant]), 'retrieval_method': 'none',
              'steps': steps, 'answer': '', 'evidence': [], 'sources': [], 'query': question}
    status, message_id = 'error', None
    access = Access(settings, store, api)
    progress = on_progress or (lambda label: None)
    try:
        context, history, evidence = {}, [], []
        if kind == 'chat':
            if profile_enabled:
                progress('Lecture du contexte utilisateur')
                try:
                    with timed_step(steps, 'Contexte utilisateur', 'context') as step:
                        context, hit = get_context(api, user_id, lambda: access.user_context(user_id))
                        step['details'] = {'cache_hit': hit, 'profile_hash': context_fingerprint(context)}
                except Exception as exc:
                    context = {}
                    steps.append({'name': 'Contexte indisponible', 'kind': 'context',
                                  'warning': type(exc).__name__})
            history = [m for m in access.visible_messages(user_id, cid, context=context)
                       if m['message_id'] != current_message_id][-8:]
        progress('Identification de la demande')
        if kind == 'chat' and mode == 'full':
            route = await route_question(api, question, history, steps, complete)
        else:
            route = {'route': 'documents', 'method': 'existing_document_mode', 'query': question}
        result['routing'] = route
        query = route['query']
        workflow = route['route']
        result['query'] = query
        needs_review = False

        if workflow == 'clarify':
            answer = ('La demande porte-t-elle sur les informations du profil, sur une règle RH '
                      'ou sur l’application d’une règle à la situation personnelle ?')
            verification = {'status': 'not_applicable', 'reason': 'clarification', 'duration_s': 0.0}
            result['answer_status'] = 'clarification'
        elif workflow == 'profile':
            catalog = profile_catalog(context)
            if not catalog:
                answer = 'Les informations du profil sont indisponibles dans le contexte chargé.'
                verification = {'status': 'not_applicable', 'reason': 'profile_unavailable', 'duration_s': 0.0}
                result['answer_status'] = 'unavailable'
            else:
                progress('Préparation de la réponse de profil')
                result['prompt_hash'] = digest(PROFILE_PROMPT)
                raw = complete(api, [{'role': 'system', 'content': PROFILE_PROMPT},
                                     {'role': 'user', 'content': json.dumps(
                                         {'question': question, 'fields': catalog}, ensure_ascii=False)}],
                               steps, 'Génération du profil',
                               trace_input={'profile_hash': context_fingerprint(context), 'field_count': len(catalog)})
                progress('Contrôle des champs du profil')
                with timed_step(steps, 'Validation du profil', 'verification') as step:
                    answer, verification = render_profile(raw, catalog)
                    step['details'] = {'method': 'api_field_binding', 'counts': verification['counts']}
                verification.update(checked_at=utcnow(), verification_version=2,
                                    answer_hash=hashlib.sha256(answer.encode()).hexdigest(),
                                    context_hash=context_fingerprint(context), duration_s=step['duration_s'])
                result.update(answer_status='full', profile_hash=context_fingerprint(context))
        else:
            context_used = context if workflow == 'mixed' else {}
            if context_used:
                result['profile_hash'] = context_fingerprint(context_used)
            # Le routeur résout aussi les reprises conversationnelles lorsqu'un
            # repli LLM est nécessaire ; aucune seconde reformulation systématique.
            result['query'] = query
            progress('Recherche des documents autorisés')
            async with mcp_session(settings, user_id) as session:
                if mode == 'full':
                    returned = await call_tool(session, 'search_documents', {'query': query}, steps)
                    steps.extend(returned.get('retrieval_steps', []))
                else:
                    returned = await call_tool(session, 'read_documents', selection, steps)
                evidence = returned['documents']
            check_current(access, evidence)
            for i, item in enumerate(evidence, 1):
                item['citation'] = i
            result['evidence'] = evidence
            result['retrieval_method'] = settings.method if mode == 'full' else 'direct'
            if not evidence and not context_used:
                answer = 'Aucune source documentaire exploitable pour cette demande.'
                verification = {'status': 'not_applicable', 'reason': 'no_evidence', 'duration_s': 0.0}
                result['answer_status'] = 'unavailable'
            else:
                progress('Rédaction de la réponse')
                system_prompt = PROMPTS[prompt_variant] + (
                    '\nProduire uniquement des puces autonomes, une par ligne, sans titre ni introduction. '
                    'Chaque puce conserve ses conditions, exceptions et limites ; ne pas les séparer '
                    'de la règle correspondante. Ne pas fusionner plusieurs sujets dans une puce. '
                    'Les faits personnels proviennent du user_context ; les règles proviennent des sources. '
                    'Ne jamais citer un numéro documentaire pour une donnée issue uniquement du profil.'
                )
                result['prompt_hash'] = digest(system_prompt)
                payload = {'date': utcnow(), 'user_context': context_used,
                           'previous_exchanges': [{'role': m['role'], 'content': m['content']} for m in history],
                           'question': question,
                           'sources': [{'citation': d['citation'], 'title': d['title'], 'text': d['text'],
                                        'source_version': d['source_version'], 'modified_at': d.get('modified_at')}
                                       for d in evidence]}
                logged_payload = dict(payload, user_context={'profile_hash': context_fingerprint(context_used)} if context_used else {})
                raw = complete(api, [{'role': 'system', 'content': system_prompt},
                                     {'role': 'user', 'content': json.dumps(payload, ensure_ascii=False, default=str)}],
                               steps, 'Génération', trace_input={'system': system_prompt, 'payload': logged_payload})
                draft = safe_answer(raw)
                result['draft_answer'] = draft
                result['draft_checks'] = citation_checks(draft, evidence)
                progress('Vérification des informations')
                with timed_step(steps, 'Vérification', 'verification') as step:
                    verification = verify_answer(settings, store, api, user_id, rid,
                        draft_result={'answer': draft, 'evidence': evidence}, steps=steps,
                        user_context=context_used)
                    step['details'] = {'status': verification['status'], 'scope': workflow,
                                       'counts': verification.get('counts', {}),
                                       'issues': [{'id': c['id'], 'verdict': c['verdict'],
                                                   'reason': c['reason'], 'warning': c.get('warning', '')}
                                                  for c in verification.get('claims', []) if c['verdict'] != 'supported']}
                    if verification['status'] == 'error':
                        step['error'] = verification.get('error') or 'VerificationError'
                selected = select_supported(verification)
                answer, needs_review = selected['answer'], selected['needs_review']
                result['answer_status'] = selected['answer_status']
                if result['answer_status'] != 'full':
                    result['rejected_answer'] = draft

        answer = safe_answer(answer)
        result['verification'] = dict(verification, automatic=True)
        result['checks'] = citation_checks(answer, evidence)
        if not result['checks']['references_valid']:
            result['rejected_answer'] = answer
            answer = 'Aucune réponse ne peut être affichée avec des références invalides.'
            result['answer_status'], needs_review = 'blocked', True
            result['checks'] = citation_checks(answer, evidence)
        result['answer'] = answer
        result.setdefault('draft_answer', answer)
        result['sources'] = cited_sources(answer, evidence)
        check_current(access, evidence)
        if kind == 'chat':
            progress('Enregistrement de la réponse')
            used = [d for d in evidence if d['citation'] in result['checks']['references_used']]
            theme = identify_theme(query)
            message_id = store.save_assistant_message(user_id, cid, question, answer, used, theme, digest(context))
            result.update(theme=theme, message_id=message_id)
        status = 'needs_review' if needs_review else 'completed'
        return result
    except Exception as exc:
        result['error'] = safe_error(exc)
        raise
    finally:
        mcp_steps = [step for step in steps if step.get('kind') == 'mcp']
        result['metrics'] = {
            'llm_calls': sum(step.get('kind') == 'llm' for step in steps),
            'mcp_calls': len(mcp_steps),
            'tool_calls': sum(step.get('kind') in {'mcp', 'tool'} for step in steps),
            'mcp_servers': len({step['server'] for step in mcp_steps if step.get('server')}),
        }
        result['metrics'].update(routing_metrics(steps, result.get('routing', {})))
        store.finish_answer_run(user_id, rid, result, status, time.perf_counter() - started, message_id)
        progress('Export de la trace')
        result['tracking_error'] = export_run(store, user_id, rid)


async def ask(settings, store, api, user_id, cid, question, *, profile_enabled=True, on_progress=None):
    store.user(user_id)
    message_id = store.save_user_message(user_id, cid, question)
    return await execute(settings, store, api, user_id, question,
                         kind='chat', mode='full', prompt_variant='renforce', cid=cid,
                         current_message_id=message_id, profile_enabled=profile_enabled, on_progress=on_progress)
