# Intégration de Semantic Router et correctifs du vérificateur

Cette version remplace la proposition antérieure. Les correctifs précédents n’étant pas encore appliqués, les fichiers sont à intégrer en une seule fois. Le dépôt réel n’est pas monté dans cet environnement ; les fonctions de remplacement sont fondées sur les signatures et le code visibles dans les captures.

## 1. Choix retenu et périmètre

Le moteur utilisé est le paquet Python officiel `semantic-router==1.1.2`, avec `Route`, `IndexedRouter` et `LocalIndex`. Le client d’embedding reste celui de l’application. Le calcul des scores, l’indexation, la calibration et la décision sous seuil utilisent les classes du framework.

| Route | Sources | Parcours |
|---|---|---|
| `profile` | Instantané API de la personne connectée | Lecture du cache backend, un appel LLM pour sélectionner et ordonner les champs, réinjection des valeurs API exactes |
| `documents` | Documents autorisés | Recherche existante, génération, vérification documentaire |
| `mixed` | Instantané API et documents autorisés | Recherche, génération et vérification avec les deux catégories de preuves |
| `clarify` | Question et historique récent | Issue du repli lorsque la demande reste ambiguë, hors périmètre ou inexploitable |

`clarify` est une issue d’orchestration, pas une quatrième classe d’exemples à forcer dans l’index. Une absence de route suffisamment étayée permet d’abord le repli LLM existant. Ce repli résout aussi les références conversationnelles et produit la requête documentaire autonome.

Les descriptions de `routes.json` servent au repli LLM et à la compréhension du catalogue. **Les phrases `utterances` sont les textes réellement vectorisés par `IndexedRouter`.** Une modification de description seule ne change pas les exemples vectoriels.

Le parcours profil conserve un appel LLM. Sa sortie est contrainte aux identifiants des champs utiles, puis le backend produit les libellés et les valeurs. Une prose libre sur les faits personnels nécessiterait un contrôle sémantique supplémentaire. Le contrôle proposé établit une conformité à l’instantané API, sans certifier la fraîcheur des données métier elles-mêmes.

## 2. Avantage sur le routeur développé précédemment

| Critère | Apport du framework | Limite |
|---|---|---|
| Décision sémantique | Classes et contrat documentés, index, agrégation et seuils communs | Les trois workflows métier restent dans `agent.py` |
| Calibration | `fit()` apprend la relation score/confiance ; `evaluate()` et l’évaluation fournie mesurent le comportement | La qualité dépend du modèle et des questions annotées |
| Maintenance | Suppression de `_unit`, `_examples` et du calcul de classement développé pour le projet | Une dépendance et ses dépendances transitives sont à maintenir |
| Extension | Catalogue de routes explicite et interfaces réutilisables | Toute nouvelle route doit aussi disposer d’un traitement autorisé dans l’orchestrateur |
| Latence | Index local, initialisation réutilisée, API évitée lorsqu’un vecteur d’exemple identique est déjà connu | Aucune accélération intrinsèque garantie par rapport à un petit calcul cosinus bien écrit |
| Observabilité | Décision native, confiance, calibration et motifs de repli accessibles | L’instrumentation MLflow est ajoutée dans le code de l’application |

Le gain de performance principal vient du choix du parcours : une demande de profil évite la reformulation documentaire, la recherche, le reranking et le juge documentaire. L’usage du framework apporte surtout un socle maintenu et évaluable ; il n’élimine pas la latence de l’API Granite ni celle du LLM de génération.

## 3. Installation dans l’environnement Python du projet

Le paquet sélectionné déclare Python `>=3.10,<3.14`, compatible avec le Python 3.13 montré dans les captures. Les commandes s’exécutent avec le `.venv` habituel actif.

```bash
python -m pip install -r requirements-routing.txt
python -m pip check
```

La configuration pip du poste peut utiliser le registre interne autorisé. Pour un transfert hors ligne, le dossier doit contenir le paquet et ses dépendances compatibles avec le poste.

```bash
python -m pip install --no-index --find-links "<DOSSIER_WHEELS>" -r requirements-routing.txt
```

Le fichier épingle le paquet direct à `1.1.2`. Les dépendances transitives restent à résoudre et à vérifier dans l’environnement cible ; aucun faux fichier de verrouillage complet n’est fourni. Aucun extra de modèle local ou de base vectorielle distante n’est nécessaire pour l’adaptateur retenu.

## 4. Fichiers à intégrer

Copier les fichiers de `app/` fournis dans le répertoire `app/` existant, ainsi que `requirements-routing.txt` à la racine.

| Fichier | Responsabilité |
|---|---|
| `app/context_cache.py` | Cache temporaire backend de l’instantané API |
| `app/response_policy.py` | Champs API, validation des preuves et restitution partielle |
| `app/routing.py` | Adaptateur Granite, Semantic Router, repli LLM, télémétrie et évaluation |
| `app/routes.json` | Descriptions, dix exemples par route et seuils de politique initiaux |
| `app/routing_examples.json` | 24 questions de calibration et 24 questions d’évaluation synthétiques distinctes |

Les fichiers de `patches/` contiennent les fonctions complètes à remplacer, avec leurs points d’insertion décrits ci-dessous. Ils ne constituent pas des modules supplémentaires à importer par l’application. Le Store conserve son schéma.

## 5. Textes des trois routes

Les textes suivants sont présents dans `app/routes.json`.

**profile** — Consultation ou présentation des données personnelles déjà retournées par l’API pour la personne connectée : identité, poste actuel, contrat s’il est présent, organisation, historique professionnel et demandes de formation. Aucune règle RH, aucun droit, aucune éligibilité ni recommandation personnalisée à déduire. Une valeur absente de l’API reste indisponible.

Exemples : « Qui suis-je ? », « Quel est mon poste actuel ? », « Résume mon parcours professionnel », « Quelles demandes de formation figurent dans mon dossier ? ».

**documents** — Recherche, explication ou résumé d’informations générales dans les documents autorisés : politiques, procédures, conditions, plafonds, équipements et règles RH. La réponse n’exige pas les caractéristiques personnelles de la personne connectée. Une question sur l’application d’une règle à sa situation relève de mixed.

Exemples : « Quelle est la politique de télétravail ? », « Résume les règles de congés », « Quelle est la procédure pour demander une formation ? ».

**mixed** — Demande exigeant à la fois les données du profil API et les documents autorisés : application d’une règle à une situation personnelle, éligibilité, droits personnalisés, comparaison au profil ou recommandation de formation fondée sur le parcours. Inclut une question combinant présentation du profil et règles générales. Le profil seul ne prouve jamais un droit.

Exemples : « Avec mon poste, suis-je éligible au télétravail ? », « Quels droits aux congés s’appliquent à mon contrat ? », « Quelles formations correspondent à mon parcours ? ».

## 6. `app/clients.py` — préserver les métadonnées de l’embedding

Ajouter `import time` si absent, puis remplacer la méthode `API.embed()` par celle de `patches/clients_embed.py`. La méthode doit conserver l’indentation des autres méthodes de la classe `API` ; la définition fournie au niveau zéro sert à faciliter sa lecture.

Les appels existants restent compatibles.

```python
vectors = api.embed(texts)
```

L’adaptateur de routage utilise les nouvelles options.

```python
reply = api.embed(texts, return_metadata=True, on_batch=record)
```

Le même appel API produit les vecteurs et les métadonnées. Chaque lot conserve sa durée, sa taille, son index, les compteurs `usage` réellement fournis et l’éventuelle classe d’erreur. Le renouvellement de jeton, les certificats, les paramètres réseau et les endpoints restent gérés par `self.call()`.

Les lots d’inférence observés ne sont pas présentés comme un décompte des tentatives HTTP : une éventuelle reprise sur 401 se produit à l’intérieur de `self.call()`. Une absence de `usage` n’est pas remplacée par une estimation de tokens facturés.

## 7. `app/agent.py` — remplacer l’orchestration

Ajouter aux imports existants.

```python
import hashlib
from app.context_cache import get_context
from app.routing import route_question, routing_metrics
from app.response_policy import (
    PROFILE_PROMPT, context_fingerprint, profile_catalog, render_profile, select_supported,
)
```

Remplacer `execute()` et `ask()` par les fonctions de `patches/agent_functions.py`. Les helpers `complete`, `call_tool`, `check_current`, `cited_sources`, le Store et `verify_recorded` restent utilisés.

Le point d’entrée du routeur est désormais asynchrone.

```python
route = await route_question(api, question, history, steps, complete)
```

L’appel se trouve après la lecture du contexte et de l’historique, avant l’ouverture de la session MCP documentaire. Seuls `documents` et `mixed` ouvrent cette session. Les évaluations documentaires et le mode `selected` conservent leur parcours explicitement choisi.

L’ancien rewriter systématique est retiré. Une question autonome conserve son texte ; une reprise conversationnelle reconnue ou une décision sémantique insuffisante passe par le repli LLM, qui classe et reformule dans le même appel. Le repérage de reprises est un garde-fou limité à quelques formulations ; ce n’est pas une compréhension exhaustive de toutes les références conversationnelles.

`result['routing']` conserve la décision, ses candidats, le catalogue effectivement chargé, ses hashes, le modèle d’embedding, la version du framework, la calibration et les paramètres appris. Aucun instantané de profil complet ni aucun vecteur de requête utilisateur n’est ajouté à cette section.

En fin de traitement, `routing_metrics(...)` complète les métriques du run existant. Les compteurs LLM et MCP restent calculés à partir des étapes réellement produites.

## 8. `app/verification.py` — périmètre corrigé

Ajouter aux imports existants.

```python
import hashlib
from app.response_policy import check_proofs, context_fingerprint, extract_blocks, profile_catalog
```

Remplacer `VERIFY_PROMPT`, `extract_claims()`, `parse_review()` et `verify_answer()` par les définitions de `patches/verification_functions.py`.

Pour `mixed`, le payload du juge reçoit les documents et le même contexte API que la génération. Pour `documents`, le contexte API est vide. Les faits personnels ne sont donc plus jugés uniquement contre les documents.

Une preuve documentaire exige une citation connue et un extrait contigu exact après normalisation Unicode et des espaces. Plusieurs extraits éloignés constituent plusieurs preuves. Une preuve API exige un chemin existant et une valeur exacte, type JSON compris ; le juge doit aussi contrôler que la preuve soutient le sens de la phrase.

Les motifs sont conservés sous `validation_errors`, notamment `quote_not_found`, `unknown_citation`, `profile_value_mismatch`, `proof_missing` et `claim_missing`. Le verdict initial du LLM et le verdict après contrôle restent distincts.

Le brouillon original et le hash de l’instantané permettent une vérification différée cohérente. Un ancien texte n’est pas comparé silencieusement à un nouveau profil. Si le résultat valide n’est pas réutilisable et si l’ancien instantané est absent, le motif est `profile_snapshot_unavailable` ; un instantané différent donne `profile_snapshot_mismatch`.

## 9. Réponses partielles et conservation des conditions

La génération documentaire produit une puce autonome par ligne. Les retours à la ligne sont conservés lors de l’extraction ; une règle et ses conditions forment une unité indivisible. Cela ne prétend pas réaliser une extraction sémantique parfaite de faits atomiques.

La sélection est effectuée après le contrôle.

```python
selected = select_supported(verification)
answer = selected['answer']
result['answer_status'] = selected['answer_status']
```

Douze blocs supportés sur treize donnent douze blocs affichés et `answer_status='partial'`. Les références finales proviennent des preuves validées. Le brouillon, les passages écartés et leurs motifs restent disponibles pour diagnostic. Les sources affichées et l’évidence mémorisée avec le message sont recalculées sur cette réponse finale.

Une erreur du juge ou une absence de bloc supporté bloque la restitution du brouillon. Le statut `completed` du vérificateur signifie que le contrôle s’est exécuté ; il ne signifie pas que toutes les affirmations sont supportées.

## 10. `app/ui.py` — cache backend et amorçage

Ajouter les imports.

```python
from app.context_cache import get_context, invalidate_context
from app.routing import warm_router
```

Dans `chat_view()`, conserver l’initialisation des identifiants et du mode invité. Remplacer les blocs « Priming » et « Récupération et affichage du profil » des captures par les opérations suivantes.

```python
access = Access(s, store, client)
st.session_state.pop('user_data', None)
if not st.session_state.get('is_guest', False):
    try:
        get_context(client, uid, lambda: access.user_context(uid))
    except Exception:
        st.warning('Les informations du profil sont indisponibles.')
```

Le même chargeur est réutilisé dans `execute()`. L’identité de la clé de cache est `uid`, cohérente avec les conversations et les contrôles documentaires. `selected_user_id` ne doit pas devenir une nouvelle source d’autorité distincte de l’identité déjà autorisée par le backend.

Supprimer l’instanciation identique de `Access` située plus bas dans `chat_view()`. Retirer l’appel UI à `fetch_full_user_context()` ; conserver ses autres usages éventuels. La carte de profil était commentée dans les captures.

Après ce bloc, amorcer le routeur pour absorber le coût de construction au chargement de l’assistant.

```python
try:
    with st.spinner('Préparation de l’assistant…'):
        asyncio.run(warm_router(client))
except Exception:
    st.caption('La préparation rapide est indisponible ; une analyse complémentaire sera utilisée.')
```

L’amorçage se fait une fois par client, modèle, révision et configuration backend. Les appels suivants réutilisent l’objet. En cas d’échec, la demande peut encore utiliser le repli LLM ; la cause sera visible dans sa trace de routage.

L’index et les calibrateurs restent dans le backend. Le cache du profil a une validité proposée de 300 secondes et une borne de 128 utilisateurs par client. Il reçoit des copies du contexte. Les entrées expirées sont purgées aux accès. Le backend est ici un processus principal unique ; les sous-processus MCP ne relisent pas le profil pour le parcours rapide.

Lors d’une déconnexion ou d’une invalidation du profil, appeler `invalidate_context(client, uid)`. Aucun token ni contexte métier complet n’est placé dans un nouvel état UI.

## 11. `app/ui.py` — étapes visibles et détails du contrôle

Dans le `try` qui entoure actuellement le spinner de génération, remplacer ce spinner par un statut alimenté par `ask()`.

```python
with st.status('Traitement de la demande', expanded=True) as status_box:
    def progress(label):
        status_box.update(label=label)
        status_box.write(label)
    result = asyncio.run(ask(
        s, store, client, uid, st.session_state.cid, question,
        profile_enabled=not st.session_state.get('is_guest', False), on_progress=progress))
    status_box.update(label='Traitement terminé', state='complete', expanded=False)
```

Conserver le `except` et le `st.rerun()` existants. Les mises à jour UI ont lieu dans le thread Streamlit ; les workers d’embedding remplissent seulement la télémétrie backend.

Remplacer `show_review()` par la fonction de `patches/ui_show_review.py`. Elle sait afficher les preuves API et documentaires. Dans la boucle d’affichage des messages, à l’intérieur du `if run`, ajouter le diagnostic.

```python
saved = run.get('result') or {}
if saved.get('answer_status') == 'partial':
    st.caption('Réponse partielle — certains passages n’ont pas été validés.')
if saved.get('verification'):
    with st.expander('Détail de la validation'):
        show_review(saved['verification'])
```

## 12. MLflow — un run par demande, des étapes imbriquées

Remplacer `_trace()` dans `app/tracking.py` par la fonction de `patches/tracking_trace.py`. Les nouveaux identifiants `step_id` et `parent_step_id` rattachent les lots d’embedding et le repli LLM à leur étape de routage. Les autres étapes conservent leur rattachement à la racine.

Le type `EMBEDDING` identifie les inférences Granite. Le routage et sa calibration sont des `CHAIN`. Un échec d’embedding marque son étape `ERROR`, même si un repli LLM permet ensuite de terminer la demande. Le résultat métier et l’état technique restent visibles séparément.

| Élément | Champs conservés |
|---|---|
| Décision | `route`, `method`, `backend`, version du framework, durée, réutilisation du routeur |
| Justification | Candidats, confiances, indicateur de calibration, seuils et motif du repli |
| Reproductibilité | Catalogue complet de routes, hashes de configuration et de jeu, modèle, révision, paramètres du calibrateur |
| Embeddings | Durée, taille et index de chaque lot, phase, modèle et `usage` observé |
| Réponse | `answer_status`, sources citées, compteurs de vérification et motifs d’exclusion |

Le modèle d’embedding est lu dans `EMBEDDING_MODEL`. `EMBEDDING_REVISION` peut identifier un changement de poids derrière le même alias ; cette valeur est une métadonnée de déploiement, pas un paramètre envoyé au modèle. Sans révision connue, la trace indique `unspecified`. Un changement de modèle ou de révision invalide le routeur en mémoire.

Les métriques produites incluent `routing_duration_s`, `routing_llm_fallback`, `routing_router_reused`, `routing_embedding_batches`, `routing_embedding_prompt_tokens_observed` et `routing_embedding_batches_without_prompt_usage`. `routing_confidence` n’est ajoutée que lorsqu’une décision sémantique expose une confiance. La confiance d’un classement LLM n’est pas inventée.

Les spans portent aussi le modèle et l’attribut standard `mlflow.chat.tokenUsage` lorsque les compteurs nécessaires sont fournis. Pour les embeddings, un compte de sortie absent peut être obtenu par la différence exacte `total_tokens - prompt_tokens` si les deux valeurs existent ; aucun total manquant n’est estimé. Les métadonnées partielles restent dans les sorties et les métriques observées. Aucun coût monétaire n’est déduit sans barème connu.

Dans `export_run()`, les métriques doivent être fusionnées avec celles déjà calculées avant l’appel à `mlflow.log_metrics`. L’extrait précédent réalisait déjà cette fusion ; conserver une seule occurrence.

```python
metrics.update(result.get('metrics', {}))
```

Dans le run MLflow déjà ouvert par `export_run()`, après l’artefact d’exécution, ajouter l’artefact de routage.

```python
if result.get('routing'):
    mlflow.log_dict(result['routing'], 'routing.json')
```

Dans ce même contexte de run, des tags facilitent le filtrage de la liste des runs.

```python
routing = result.get('routing', {})
mlflow.set_tags({f'routing.{key}': str(routing[key])
    for key in ('route', 'method', 'framework_version', 'config_hash')
    if routing.get(key) is not None})
```

La trace porte les mêmes tags. Le hash du code de l’adaptateur, celui du prompt de repli et les références des messages utilisés pour la résolution conversationnelle complètent la provenance. Le profil complet n’est pas recopié dans ce diagnostic.

Conserver `verification.json`. Si `export_run()` appelle aussi `_verification_trace()`, réserver cet appel à une vérification manuelle : la vérification automatique figure déjà dans la trace de la demande.

```python
if verification and not verification.get('automatic'):
    _verification_trace(mlflow, run, verification, evidence, experiment_id)
```

Ce garde-fou concerne le point d’appel déjà présent ; les noms locaux sont à conserver s’ils diffèrent. Il ne faut pas ajouter un second appel à `_verification_trace`.

L’amorçage effectué avant la demande apparaît ensuite dans les métadonnées `calibration.initialization`. Ses tokens ne sont pas additionnés aux lots de la demande en cours. Si l’amorçage a lieu pendant la première demande, ses étapes sont incluses dans cette trace et ses lots sont comptés pour cette demande. La réutilisation d’un vecteur d’exemple identique ne crée pas de lot fictif.

L’export reste synchrone et l’UI affiche cette phase. La durée historique du run, mesurée avant l’export, ne représente donc pas toute la latence visible par l’utilisateur.

## 13. Calibration initiale et évaluation avec Granite

La construction du routeur vectorise les 30 exemples et exécute la calibration native sur les 24 questions de `routing_examples.json`. Les questions de test sont séparées. Les questions réelles des utilisateurs ne sont pas ajoutées automatiquement à ces jeux ni au cache de vecteurs statiques.

Les seuils `0.90` pour `profile` et `0.85` pour les autres routes constituent une politique initiale à vérifier. Ils ne représentent pas une précision observée sur les demandes réelles. La calibration actuelle est explicitement étiquetée `synthetic_bootstrap`.

Depuis une fonction disposant du client déjà authentifié, l’évaluation du moteur sémantique seul peut être lancée ainsi.

```python
from app.routing import evaluate_routing
report = asyncio.run(evaluate_routing(client))
```

Le rapport fournit la précision sur les décisions acceptées, la couverture sémantique, les confusions `mixed` vers `profile`, la précision de `profile` et les prédictions par exemple. Il exclut le repli LLM pour ne pas masquer les limites du moteur rapide. Une précision absente faute de décision acceptée vaut `None`, pas une réussite à 100 %.

Les métriques `calibration.accuracy` et `calibration.ece` décrivent l’ajustement sur le jeu de calibration. La précision et la couverture du rapport d’évaluation décrivent le jeu de test séparé. Aucune de ces mesures ne constitue une garantie sur tous les messages futurs.

Une modification du catalogue, du jeu, du modèle, de sa révision ou de la version du framework provoque une reconstruction et une calibration. Aucune suppression d’une route dans le JSON ne laisse une ancienne route dans cet index neuf.

## 14. Contrôles et limites de validation

Le contrôle reproductible après installation normale du paquet est le suivant.

```bash
python validation/test_synthetic.py
```

Les tests couvrent les trois parcours, le contexte du juge, la réponse partielle, les citations finales, le cache, les métadonnées par lot, les replis, l’absence de double embedding pour les deux lectures d’index et le rattachement des spans MLflow.

Dans l’environnement de préparation, PyPI répond HTTP 403. L’installation complète du paquet et de ses SDK n’a donc pas pu être vérifiée. Les 30 tests ont été exécutés sur les modules de calcul officiels non modifiés du commit `5713bef32f31b3e07eb7826b07fcf064b968df90`, déclarant la version `1.1.2`. Le harnais local contourne seulement les initialisateurs qui importent tous les fournisseurs non utilisés et remplace le logger coloré par le logger standard. Les classes d’indexation, de calibration et de routage sont celles du dépôt officiel.

Les vecteurs, le client métier, le Store, le LLM et l’objet MLflow utilisés dans ces tests sont synthétiques. Les durées et la précision obtenues ne mesurent pas Granite, le serveur MLflow réel ni l’application complète. Le rapport à produire avec le client interne reste nécessaire pour mesurer les performances du routage réel.

## 15. Références primaires

Les parts suivantes sont des estimations de contribution documentaire à cette intégration, pas des scores de fiabilité.

| Référence | Contribution | Part |
|---|---|---|
| [Semantic Router, routeurs](https://docs.aurelio.ai/docs/semantic-router/v1/user-guide/components/routers) | IndexedRouter, agrégation, appels asynchrones | 25 % |
| [Semantic Router, encodeurs](https://docs.aurelio.ai/docs/semantic-router/v1/client-reference/encoders/base) | Adaptateur vers le client existant | 15 % |
| [Semantic Router, calibration](https://docs.aurelio.ai/docs/semantic-router/v1/user-guide/features/calibration) | Ajustement et séparation des jeux | 25 % |
| [MLflow, tracing manuel](https://www.mlflow.org/docs/latest/genai/tracing/app-instrumentation/manual-tracing/) | Spans, entrées, sorties et états techniques | 20 % |
| [Paquet officiel Semantic Router](https://pypi.org/project/semantic-router/1.1.2/) | Version et compatibilité Python | 15 % |

Le code du cœur a également été contrôlé dans [le dépôt officiel au commit de validation](https://github.com/aurelio-labs/semantic-router/tree/5713bef32f31b3e07eb7826b07fcf064b968df90). Les descriptions et les jeux RH fournis sont des propositions synthétiques propres à cette intégration.
